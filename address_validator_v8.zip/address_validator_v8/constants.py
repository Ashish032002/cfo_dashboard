
"""
constants.py
Thresholds, stopwords, aliases, and utility globals.
"""
CITY_THRESHOLD = 0.60   # similarity threshold for city
STATE_THRESHOLD = 0.70  # similarity threshold for state
HIGH_CONF = 0.85
MED_CONF  = 0.65

# scoring weights (only pincode/city/state; NO locality/office in scoring)
W_PIN  = 0.50
W_CITY = 0.30
W_STATE= 0.20

STOP_WORDS = {
    "division","city","district","region","circle","zone","south","north",
    "east","west","office","so","s.o","bo","b.o","po","p.o","head","branch",
    "rms","ho","do","co","post","nodal","sub","urban","rural","taluk","mandal",
    "near","opp","opposite","behind","beside","next","to","old","new","nr",
    "at","the","and","road","rd","street","st","phase","ph","sector","sec",
    "block","blk","lane","ln","tower","twr","bldg","building","flr","floor",
    "gate","nagar","vihar","colony","layout","society","socty","apt","apartment"
}

CITY_ALIASES = {
    "bombay":"mumbai","bengaluru":"bangalore","bengluru":"bangalore",
    "benglore":"bangalore","calcutta":"kolkata","trivandrum":"thiruvananthapuram",
    "cochin":"kochi","baroda":"vadodara","pondicherry":"puducherry",
    "nasik":"nashik","gurgaon":"gurugram","ahmadabad":"ahmedabad"
}

LOCALITY_CUES = [
    "sector","sec","phase","ph","block","blk","lane","ln","road","rd","street","st","nagar",
    "vihar","colony","layout","society","socty","apt","apartment","tower","twr","bldg","building",
    "market","bazaar","bazar","gali","marg","circle","chowk","gate"
]
