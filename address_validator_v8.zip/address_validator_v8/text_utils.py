
import re, unicodedata
from rapidfuzz import fuzz

def strip_accents(s): 
    return ''.join(ch for ch in unicodedata.normalize('NFKD', str(s)) if not unicodedata.combining(ch))

def clean_text(s):
    s = strip_accents(str(s or '')).lower()
    s = re.sub(r'[^\w\s]', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def token_set_sim(a,b):
    return fuzz.token_set_ratio(a or '', b or '')/100

PIN_RE = re.compile(r'(?<!\d)(\d{6})(?!\d)')

def extract_pin(txt):
    if not txt: return None
    m = PIN_RE.search(str(txt))
    return m.group(1) if m else None
