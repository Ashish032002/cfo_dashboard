
# Address Validator v8 (Flowchart-Accurate)

This version fully implements **all branches** of the provided flowchart image:
- **Pincode present & found in India DB** → choose best (city/state) candidate; flag on ambiguity/mismatch; score uses only city/state/pincode.
- **Pincode present but NOT found** → `FLAG` with reason *"6-digit pincode not in India DB (Foreign/Invalid)"*.
- **No pincode** → derive/validate by city/state with ambiguity checks (same-name city in multiple states, missing state, etc.).
- **Multiple/ambiguous states** → `FLAG` with suggestions.
- **Multiple countries / conflicts** → (not expected for Indian DB; anything outside resolves to Low confidence + FLAG).

## Key Rules
- **No office/PO name used** anywhere (removed entirely).
- **Locality** is extracted **only from input address** using cue words and stopword filtering (`locality.py`). Not used in scoring.
- **Scoring** uses only **pincode match (boolean), city similarity, state similarity** with weights in `constants.py`:
  - `W_PIN=0.5`, `W_CITY=0.3`, `W_STATE=0.2`
  - Confidence levels: `High>=0.85`, `Medium>=0.65`, else `Low`.
- **Primary keys**:
  - `av.input_addresses.input_id BIGSERIAL` (auto-added if missing)
  - `av.validation_result_final.validation_id BIGSERIAL`

## Tables
- Input: `av.input_addresses(address1,address2,address3,city,state,pincode,country, input_id)`
- Master: `av.master_ref(pincode,state,city)`
- Output: `av.validation_result_final(validation_id, input_id, ..., suggestions jsonb)`

## How to run
1. Edit your DB connection in `db_config.py`.
2. Ensure `av.master_ref` and `av.input_addresses` exist and are populated (you can use the provided `schema.sql` baseline).
3. Execute as a module:
   ```bash
   python -m address_validator_v8.main
   ```
   An Excel artifact `validation_results_v8.xlsx` will be created in `/mnt/data/` and the DB table will be written.

## Notes
- `state_maps.py` expects `abbreviation_list.csv` co-located with the package (drop your CSV next to these files if needed).
- The engine covers **all flowchart cases**, including the *No/Yes* branches. It **does not** "only follow yes path for pincode"—
  non-pin paths, ambiguous cities, missing states, and mismatches are explicitly handled and flagged with suggestions.
