
-- Create schema and base tables (run once)
CREATE SCHEMA IF NOT EXISTS av;

-- Master pincode reference (must be pre-populated)
-- Columns required: pincode (TEXT/CHAR(6)), state (TEXT), city (TEXT)
CREATE TABLE IF NOT EXISTS av.master_ref (
    pincode TEXT, state TEXT, city TEXT
);

-- Input addresses; primary key input_id added if missing by the app
CREATE TABLE IF NOT EXISTS av.input_addresses (
    address1 TEXT, address2 TEXT, address3 TEXT,
    city TEXT, state TEXT, pincode TEXT, country TEXT
);
