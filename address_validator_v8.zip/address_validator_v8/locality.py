
import re
from .text_utils import clean_text
from .constants import STOP_WORDS, LOCALITY_CUES

CUE_RE = re.compile(r'\b(' + '|'.join(re.escape(c) for c in LOCALITY_CUES) + r')\b', re.IGNORECASE)

def extract_locality(addr_raw, city=None, state=None, pincode=None):
    """
    Extract locality purely from input address using cue words and stopword filtering.
    - Remove city/state/pincode tokens
    - Keep surrounding phrase near locality cues
    - As fallback, return top-N longest tokens excluding stopwords
    """
    if not addr_raw: 
        return None
    base = clean_text(addr_raw)
    # remove explicit city/state/pincode tokens
    for token in [str(city or ''), str(state or ''), str(pincode or '')]:
        t = clean_text(token)
        if t:
            base = base.replace(t, ' ')
    base = re.sub(r'\s+', ' ', base).strip()
    
    # Try to capture window around locality cues
    m = CUE_RE.search(addr_raw or '')
    if m:
        # capture up to ~6 words around cue
        words = (addr_raw or '').split()
        idx = 0
        # find index of cue word in original split (case-insensitive)
        for i,w in enumerate(words):
            if re.fullmatch(m.re, w) or w.lower() == m.group(1).lower():
                idx = i; break
        start = max(0, idx-3); end = min(len(words), idx+6)
        snippet = " ".join(words[start:end])
        return snippet.strip()
    
    # else: take meaningful tokens (not stopwords) as locality
    toks = [t for t in base.split() if t not in STOP_WORDS and not t.isdigit()]
    toks = sorted(set(toks), key=lambda x:(-len(x), x))
    return " ".join(toks[:5]) if toks else None
