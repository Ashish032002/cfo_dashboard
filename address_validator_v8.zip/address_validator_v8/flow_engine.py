
"""
Implements the full decision logic from the provided flowchart.
No "office_name" usage. Locality comes from input address only.
Scores use only pincode, city, and state.
"""
import pandas as pd
from dataclasses import dataclass
from typing import Optional, List, Dict, Tuple
from .text_utils import clean_text, token_set_sim, extract_pin
from .state_maps import load_state_mappings, normalize_state
from .constants import CITY_THRESHOLD, STATE_THRESHOLD, W_PIN, W_CITY, W_STATE, HIGH_CONF, MED_CONF, CITY_ALIASES
from .locality import extract_locality

def normalize_city(s:str)->str:
    s = clean_text(s)
    toks = [CITY_ALIASES.get(t,t) for t in s.split()]
    return " ".join(toks).title()

@dataclass
class Decision:
    status: str            # "OK" | "FLAG"
    reason: str
    confidence: float
    confidence_level: str
    chosen: Dict           # chosen (city,state,pincode,country)
    suggestions: List[Dict]  # alternative candidates from master

def score(city_sim:float, state_sim:float, pin_match:bool)->float:
    return W_CITY*city_sim + W_STATE*state_sim + W_PIN*(1.0 if pin_match else 0.0)

def conf_level(score:float)->str:
    if score >= HIGH_CONF: return "High"
    if score >= MED_CONF:  return "Medium"
    return "Low"

class AddressValidator:
    def __init__(self, master_df: pd.DataFrame, state_csv_path: Optional[str]=None):
        """
        master_df must have columns: pincode, state, city
        """
        self.master = master_df.copy()
        self.master["pincode"] = self.master["pincode"].astype(str).str.extract(r'(\d{6})')
        self.master["city_norm"]  = self.master["city"].apply(normalize_city)
        st_to_abbr, abbr_to_st = load_state_mappings(state_csv_path)
        self.state_to_abbr = st_to_abbr
        self.abbr_to_state = abbr_to_st
        self.master["state_norm"] = self.master["state"].apply(
            lambda s: normalize_state(s, self.state_to_abbr, self.abbr_to_state)
        )
        self.by_pin = {k:v for k,v in self.master.groupby("pincode")}
        self.city_index = self.master.drop_duplicates(subset=["city_norm","state_norm"])

    # ---------- Flow helpers ----------
    def _derive_candidates_from_pin(self, pin:str)->List[Dict]:
        if pin not in self.by_pin: return []
        df = self.by_pin[pin][["pincode","city_norm","state_norm"]].drop_duplicates()
        return [dict(pincode=r.pincode, city=r.city_norm, state=r.state_norm, country="India")
                for r in df.itertuples(index=False)]

    def _guess_city_from_text(self, addr_clean:str)->List[str]:
        # naive guess: find tokens that equal a known city
        tokens = set(addr_clean.title().split())
        present = self.city_index[self.city_index["city_norm"].isin(tokens)]["city_norm"].unique().tolist()
        return present

    def decide(self, addr_row: Dict)->Decision:
        """
        Implements all branches of the flowchart.
        addr_row expects keys: address1, address2, address3, city, state, pincode (optional), country (optional)
        """
        addr_raw = " ".join([str(x) for x in [addr_row.get("address1"), addr_row.get("address2"), addr_row.get("address3")] if x and str(x).lower()!="nan"]).strip()
        addr_clean = clean_text(addr_raw)
        pin = extract_pin(addr_raw) or extract_pin(addr_row.get("pincode"))
        inp_city  = normalize_city(addr_row.get("city") or "")
        inp_state = normalize_state(addr_row.get("state") or "", self.state_to_abbr, self.abbr_to_state)

        # LOCALITY (from input only)
        locality = extract_locality(addr_raw, inp_city, inp_state, pin)

        # ==== Branch 1: PIN present? ====
        if pin:
            if pin in self.by_pin:
                # Pincode in India DB
                cands = self._derive_candidates_from_pin(pin)
                # try to choose best by city/state similarity
                best = None; best_score=-1.0
                for c in cands:
                    c_city = c["city"]; c_state = c["state"]
                    city_sim  = token_set_sim(c_city, inp_city) if inp_city else 0.0
                    state_sim = token_set_sim(c_state, inp_state) if inp_state else 0.0
                    s = score(city_sim, state_sim, True)
                    if s > best_score:
                        best_score = s; best = c
                chosen = best or (cands[0] if cands else {"pincode":pin, "city":None, "state":None, "country":"India"})
                s = best_score if best else 0.5  # minimal credit because pin matched
                level = conf_level(s)

                # Ambiguity check: multiple distinct cities for this pin and weak city/state evidence
                if len({c["city"] for c in cands})>1 and (token_set_sim(chosen["city"], inp_city) < CITY_THRESHOLD):
                    return Decision(
                        status="FLAG",
                        reason="Ambiguous: pincode maps to multiple cities; city in input does not clearly match",
                        confidence=s, confidence_level=level, chosen=chosen, suggestions=cands
                    )
                # Mismatch check: strong disagreement between input and master
                if inp_city and chosen["city"] and token_set_sim(chosen["city"], inp_city) < 0.40:
                    return Decision(
                        status="FLAG",
                        reason="City mismatch with master for the given pincode",
                        confidence=s, confidence_level=level, chosen=chosen, suggestions=cands
                    )
                if inp_state and chosen["state"] and token_set_sim(chosen["state"], inp_state) < 0.50:
                    return Decision(
                        status="FLAG",
                        reason="State mismatch with master for the given pincode",
                        confidence=s, confidence_level=level, chosen=chosen, suggestions=cands
                    )
                # OK path
                return Decision(status="OK", reason="Pincode found in DB", confidence=s, confidence_level=level, chosen=chosen, suggestions=cands)

            else:
                # 6-digit but not in India DB -> Foreign/Invalid
                return Decision(status="FLAG", reason="6-digit pincode not in India DB (Foreign/Invalid)", confidence=0.0, confidence_level="Low",
                                chosen={"pincode":pin, "city":inp_city or None, "state":inp_state or None, "country":addr_row.get("country") or None},
                                suggestions=[])

        # ==== Branch 2: NO PIN ===
        # Try extract city from address text if not provided
        if not inp_city:
            guesses = self._guess_city_from_text(addr_clean)
            if len(guesses) == 1:
                inp_city = guesses[0]
            elif len(guesses) > 1:
                # Ambiguous city
                return Decision(status="FLAG", reason="No pincode and multiple possible cities detected in text", confidence=0.0, confidence_level="Low",
                                chosen={"pincode":None, "city":None, "state":inp_state or None, "country":None}, suggestions=[{"city":g} for g in guesses])

        # With city known (from input or guessed), check if in DB
        city_rows = self.city_index[self.city_index["city_norm"]==inp_city] if inp_city else pd.DataFrame()
        if not city_rows.empty:
            # city in DB -> derive possible states/countries (India)
            states_for_city = city_rows["state_norm"].unique().tolist()
            if inp_state:
                # validate state
                state_sim = max([token_set_sim(s, inp_state) for s in states_for_city]) if states_for_city else 0.0
                s = score(city_sim=1.0, state_sim=state_sim, pin_match=False)
                lvl = conf_level(s)
                if state_sim < STATE_THRESHOLD:
                    return Decision(status="FLAG", reason="City found but state mismatch / ambiguous", confidence=s, confidence_level=lvl,
                                    chosen={"pincode":None,"city":inp_city,"state":None,"country":"India"}, suggestions=[{"city":inp_city,"state":st,"country":"India"} for st in states_for_city])
                return Decision(status="OK", reason="City & State validated without pincode", confidence=s, confidence_level=lvl,
                                chosen={"pincode":None, "city":inp_city, "state":normalize_state(inp_state, self.state_to_abbr, self.abbr_to_state), "country":"India"},
                                suggestions=[{"city":inp_city,"state":st,"country":"India"} for st in states_for_city])
            else:
                # No state provided -> ambiguous if city exists in multiple states
                if len(states_for_city) > 1:
                    return Decision(status="FLAG", reason="Ambiguous: same city name exists in multiple states", confidence=0.0, confidence_level="Low",
                                    chosen={"pincode":None, "city":inp_city, "state":None, "country":"India"},
                                    suggestions=[{"city":inp_city,"state":st,"country":"India"} for st in states_for_city])
                else:
                    # single state
                    s = score(city_sim=1.0, state_sim=1.0, pin_match=False)
                    return Decision(status="OK", reason="City uniquely maps to a single state", confidence=s, confidence_level=conf_level(s),
                                    chosen={"pincode":None, "city":inp_city, "state":states_for_city[0], "country":"India"}, suggestions=[])

        # city not in DB -> try with state only
        if inp_state:
            # If state exists in DB?
            if inp_state in self.master["state_norm"].unique().tolist():
                # Medium confidence with state match only
                s = score(city_sim=0.0, state_sim=1.0, pin_match=False)
                return Decision(status="OK", reason="State recognized; city unknown", confidence=s, confidence_level=conf_level(s),
                                chosen={"pincode":None, "city":inp_city or None, "state":inp_state, "country":"India"}, suggestions=[])
            else:
                return Decision(status="FLAG", reason="Provided state not recognized in DB", confidence=0.0, confidence_level="Low",
                                chosen={"pincode":None, "city":inp_city or None, "state":inp_state, "country":None}, suggestions=[])

        # Neither pin nor recognized city/state
        return Decision(status="FLAG", reason="No pincode and could not derive city/state", confidence=0.0, confidence_level="Low",
                        chosen={"pincode":None, "city":None, "state":None, "country":None}, suggestions=[])
