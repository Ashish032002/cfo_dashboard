
"""
main.py
End-to-end batch validator respecting the flowchart logic and new rules:
- NO office/PO fields in scoring
- Locality extracted only from input address text
- Provide primary keys for both input and output tables
- Suggestions include master candidates (pincode->city/state)
"""
import pandas as pd
from sqlalchemy import text
from tqdm import tqdm
from .db_config import get_db_connection
from .flow_engine import AddressValidator
from .text_utils import extract_pin
from .state_maps import load_state_mappings, normalize_state
from .locality import extract_locality

INPUT_TABLE  = "av.input_addresses"     # expected columns: address1,address2,address3,city,state,pincode,country (optional)
MASTER_TABLE = "av.master_ref"          # expected columns: pincode,state,city
OUTPUT_TABLE = "av.validation_result_final"

def ensure_schema_and_ids(engine):
    with engine.begin() as con:
        # Add surrogate primary key to input if absent
        con.execute(text(f"""
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_schema='av' AND table_name='input_addresses' AND column_name='input_id'
          ) THEN
            ALTER TABLE {INPUT_TABLE} ADD COLUMN input_id BIGSERIAL PRIMARY KEY;
          END IF;
        END $$;
        """))
        # Create output table fresh
        con.execute(text(f"DROP TABLE IF EXISTS {OUTPUT_TABLE} CASCADE;"))
        con.execute(text(f"""
        CREATE TABLE {OUTPUT_TABLE} (
          validation_id BIGSERIAL PRIMARY KEY,
          input_id BIGINT,
          address1 TEXT, address2 TEXT, address3 TEXT,
          city TEXT, state TEXT, pincode TEXT, country TEXT,
          derived_city TEXT, derived_state TEXT, derived_pincode TEXT, derived_country TEXT,
          locality TEXT,
          status TEXT,       -- OK / FLAG
          reason TEXT,
          confidence NUMERIC,
          confidence_level TEXT,
          suggestions JSONB
        );
        """))

def run():
    print("Starting Address Validator v8 ...")
    eng = get_db_connection()
    ensure_schema_and_ids(eng)
    with eng.begin() as con:
        master = pd.read_sql(f"SELECT pincode, state, city FROM {MASTER_TABLE}", con)
        inputs = pd.read_sql(f"SELECT * FROM {INPUT_TABLE} ORDER BY input_id", con)

    validator = AddressValidator(master)

    results = []
    for r in tqdm(inputs.to_dict(orient="records")):
        decision = validator.decide(r)
        # Build row
        locality = extract_locality(" ".join([str(r.get('address1') or ''), str(r.get('address2') or ''), str(r.get('address3') or '')]),
                                    r.get('city'), r.get('state'), r.get('pincode'))
        out = {
            "input_id": r.get("input_id"),
            "address1": r.get("address1"), "address2": r.get("address2"), "address3": r.get("address3"),
            "city": r.get("city"), "state": r.get("state"), "pincode": r.get("pincode"), "country": r.get("country"),
            "derived_city": decision.chosen.get("city"), "derived_state": decision.chosen.get("state"),
            "derived_pincode": decision.chosen.get("pincode"), "derived_country": decision.chosen.get("country"),
            "locality": locality,
            "status": decision.status, "reason": decision.reason,
            "confidence": round(float(decision.confidence or 0.0), 3),
            "confidence_level": decision.confidence_level,
            "suggestions": decision.suggestions
        }
        results.append(out)

    out_df = pd.DataFrame(results)
    # Write to DB
    with eng.begin() as con:
        # Pandas to_sql for speed; then add PK defaults should already be set
        out_df.to_sql(OUTPUT_TABLE.split('.')[-1], con, schema=OUTPUT_TABLE.split('.')[0], if_exists='append', index=False)
    # Also write an Excel artifact
    xlsx_path = "/mnt/data/validation_results_v8.xlsx"
    out_df.to_excel(xlsx_path, index=False)
    print(f"Saved {xlsx_path}")
    return xlsx_path

if __name__ == "__main__":
    run()
