
"""
db_config.py
Provide a SQLAlchemy engine via get_db_connection().
Replace the placeholder with your actual connection string.
"""
from sqlalchemy import create_engine

# Example: postgresql+psycopg2://user:pass@host:5432/dbname
CONN_STR = "postgresql+psycopg2://postgres:postgres@localhost:5432/postgres"

def get_db_connection():
    return create_engine(CONN_STR, pool_pre_ping=True)
