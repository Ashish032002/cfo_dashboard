
import os, pandas as pd
from .text_utils import clean_text

def load_state_mappings(abbrev_csv_path=None):
    """
    Load 'State' and 'Abbreviation' mapping. Returns two dicts.
    """
    if abbrev_csv_path is None:
        # default co-located csv name; change if needed
        abbrev_csv_path = os.path.join(os.path.dirname(__file__), "abbreviation_list.csv")
    df = pd.read_csv(abbrev_csv_path)
    df.columns = df.columns.str.strip().str.title()
    df["State"] = df["State"].astype(str).str.strip().str.title()
    df["Abbreviation"] = df["Abbreviation"].astype(str).str.strip().str.upper()
    state_to_abbr = dict(zip(df["State"], df["Abbreviation"]))
    abbr_to_state = dict(zip(df["Abbreviation"], df["State"]))
    return state_to_abbr, abbr_to_state

def normalize_state(s, state_to_abbr, abbr_to_state):
    from rapidfuzz import process
    if not s: return None
    s_clean = clean_text(str(s)).replace('.', '').upper().strip()
    if s_clean in abbr_to_state:
        return abbr_to_state[s_clean]
    stitle = s_clean.title()
    if stitle in state_to_abbr:
        return stitle
    # fuzzy to known state names
    best, score, _ = process.extractOne(stitle, list(state_to_abbr.keys()))
    return best if score >= 85 else stitle
