import re, json, pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

try:
    from rapidfuzz import fuzz
    def sim(a,b): return fuzz.token_set_ratio(a or '', b or '')/100
except:
    import difflib
    def sim(a,b): return difflib.SequenceMatcher(None,(a or '').lower(),(b or '').lower()).ratio()

def extract_pin(txt):
    if not txt: return None
    m=re.search(r"(?<!\d)(\d{6})(?!\d)", str(txt))
    return m.group(1) if m else None

def main():
    eng=get_db_connection()
    with eng.begin() as con:
        master=pd.read_sql("SELECT * FROM av.master_ref",con)
        inp=pd.read_sql("SELECT * FROM av.input_address ORDER BY id",con)

    results=[]
    for _,r in inp.iterrows():
        addr=" ".join([str(x) for x in [r.address1,r.address2,r.address3] if x and x!='nan']).strip()
        pin=extract_pin(addr) or extract_pin(r.pincode)
        city_in=str(r.city or '').strip().title()
        state_in=str(r.state or '').strip().title()
        country="India"
        loc=None
        city_conf=state_conf=country_conf=0

        m_city=master[master['pincode']==pin] if pin else master
        if not m_city.empty:
            m_city['cs']=m_city['city'].apply(lambda x: sim(x,city_in))
            best=m_city.sort_values('cs',ascending=False).head(1).iloc[0]
            loc=best.office_name
            city_conf=best.cs
            state_conf=sim(best.state,state_in)
        else:
            best=None

        country_conf=1.0 if country.lower()=="india" else 0.5
        overall=(0.5*city_conf+0.3*state_conf+0.2*country_conf)
        flag="High" if overall>=0.85 else ("Medium" if overall>=0.6 else "Low")

        results.append({
            "Address1":addr,
            "City":best.city if best is not None else city_in,
            "State":best.state if best is not None else state_in,
            "Pincode":pin,
            "Country":country,
            "City_Confidence":round(city_conf,3),
            "State_Confidence":round(state_conf,3),
            "Country_Confidence":round(country_conf,3),
            "Overall_Confidence":round(overall,3),
            "Flag":flag,
            "Locality":loc
        })

    df=pd.DataFrame(results)
    df.to_excel("validated_output_final.xlsx",index=False)
    with eng.begin() as con:
        con.execute(text("DROP TABLE IF EXISTS av.validation_result_final"))
        con.execute(text("CREATE TABLE av.validation_result_final(address1 TEXT, city TEXT, state TEXT, pincode TEXT, country TEXT, city_confidence NUMERIC, state_confidence NUMERIC, country_confidence NUMERIC, overall_confidence NUMERIC, flag TEXT, locality TEXT)"))
        for _,row in df.iterrows():
            con.execute(text("INSERT INTO av.validation_result_final(address1,city,state,pincode,country,city_confidence,state_confidence,country_confidence,overall_confidence,flag,locality) VALUES(:a,:c,:s,:p,:co,:cc,:sc,:coc,:oc,:f,:l)"),
                        {"a":row.Address1,"c":row.City,"s":row.State,"p":row.Pincode,"co":row.Country,"cc":row.City_Confidence,"sc":row.State_Confidence,"coc":row.Country_Confidence,"oc":row.Overall_Confidence,"f":row.Flag,"l":row.Locality})
    print("Validation completed, results in av.validation_result_final and Excel file.")

if __name__=="__main__":
    main()
