import pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

def main():
    engine = get_db_connection()
    df = pd.read_csv("master_data.csv")
    df.columns = df.columns.str.lower().str.strip()
    df = df.rename(columns={'divisionname':'city','statename':'state'})
    df['city'] = df['city'].astype(str).str.strip().str.title()
    df['state'] = df['state'].astype(str).str.strip().str.title()
    df['pincode'] = df['pincode'].astype(str).str.extract(r'(\d{6})', expand=False)
    df['office_name'] = df['officename'].astype(str).str.title()
    df = df[['city','state','pincode','office_name']].dropna(subset=['pincode'])
    with engine.begin() as con:
        con.execute(text("DROP TABLE IF EXISTS av.master_ref"))
        con.execute(text("CREATE TABLE IF NOT EXISTS av.master_ref(city TEXT, state TEXT, pincode TEXT, office_name TEXT)"))
        for _, r in df.iterrows():
            con.execute(text("INSERT INTO av.master_ref(city,state,pincode,office_name) VALUES(:c,:s,:p,:o)"),
                        {"c":r['city'],"s":r['state'],"p":r['pincode'],"o":r['office_name']})
    print("Master data loaded into av.master_ref")

if __name__ == "__main__":
    main()
