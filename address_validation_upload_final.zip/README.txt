Simplified Address Validation (Postgres)
----------------------------------------

Files:
  db_config.py                - Postgres connector
  upload_master_data_final.py - loads master_data.csv (divisionname -> City)
  upload_input_data.py        - loads Input_address_2.xlsx
  validator_final_simplified.py - runs validation & inserts results

Steps:
  1. python upload_master_data_final.py
  2. python upload_input_data.py
  3. python validator_final_simplified.py

Output Excel Columns:
  Address1 | City | State | Pincode | Country | City_Confidence |
  State_Confidence | Country_Confidence | Overall_Confidence | Flag | Locality

Notes:
  - Country is fixed as 'India'.
  - Locality extracted from matching office_name.
  - Only insertion code for Postgres, no schema creation.
