package com.cams.core.rulesui.scm.dto;

public class FileRef (RepoRef repo , String branch , String path){
}
