package com.cams.core.rulesui.scm.dto;

public class ScmFile(String path , String content , String revision) {
}
