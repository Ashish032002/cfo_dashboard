package com.cams.core.rulesui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RulesUiClientBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(RulesUiClientBackendApplication.class, args);
    }
}