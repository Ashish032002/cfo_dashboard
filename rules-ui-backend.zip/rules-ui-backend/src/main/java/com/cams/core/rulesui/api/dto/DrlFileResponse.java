package com.cams.core.rulesui.api.dto;

public class DrlFileResponse (
    String project,
    String branch,
    String path,
    String revision,
    String content
    ){}
