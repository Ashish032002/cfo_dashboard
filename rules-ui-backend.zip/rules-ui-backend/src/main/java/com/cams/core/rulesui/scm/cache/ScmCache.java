package com.cams.core.rulesui.scm.cache;

public class ScmCache {
    Optional<V> get(String key);
    void put(String key, V value);
    void evict(String key);
    void clear();
}
