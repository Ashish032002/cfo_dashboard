package com.cams.core.rulesui.scm.dto;

public class RepoRef (String baseUrl , String project){
}
