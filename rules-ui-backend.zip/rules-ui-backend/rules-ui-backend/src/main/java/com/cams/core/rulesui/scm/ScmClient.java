package com.cams.core.rulesui.scm;

import com.cams.core.rulesui.scm.dto.*;

import java.util.List;

public interface ScmClient {
    ScmFile getFile(FileRef ref);
    List<String> listFiles(RepoRef repo, String branch, String folderPath);
}
