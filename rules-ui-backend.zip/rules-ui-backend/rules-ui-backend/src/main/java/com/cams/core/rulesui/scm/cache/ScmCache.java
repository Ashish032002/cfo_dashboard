package com.cams.core.rulesui.scm.cache;

import java.util.Optional;

public interface ScmCache<V> {
    Optional<V> get(String key);
    void put(String key, V value);
    void evict(String key);
    void clear();
}
