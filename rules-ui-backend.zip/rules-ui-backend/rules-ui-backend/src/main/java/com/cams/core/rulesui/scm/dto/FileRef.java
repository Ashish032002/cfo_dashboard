package com.cams.core.rulesui.scm.dto;

public record FileRef (RepoRef repo , String branch , String path){
}
