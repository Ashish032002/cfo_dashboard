package com.cams.core.rulesui.scm.dto;

public record ScmFile(String path , String content , String revision) {
}
