package com.cams.core.rulesui.api.dto;

public record DrlFileResponse (
    String project,
    String branch,
    String path,
    String revision,
    String content
    ){}
