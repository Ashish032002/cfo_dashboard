package com.cams.core.rulesui.scm.dto;

public record RepoRef (String baseUrl , String project){
}
