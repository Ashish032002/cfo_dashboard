
# Address Validator v15

- Fuzzy city matching (≥ 0.75)
- Detect master city inside full address (≥ 0.80) to avoid false mismatches
- Confidence: High ≥ 0.80, Medium 0.65–0.80, Low < 0.65
- 10k batch, Excel per batch, DB insert per batch
