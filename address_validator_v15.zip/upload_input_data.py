
import os, pandas as pd, re
from sqlalchemy import text
from db_config import get_db_connection

def norm_pin(s):
    if pd.isna(s): return None
    m = re.search(r'(\d{6})', str(s))
    return m.group(1) if m else None

def main():
    eng = get_db_connection()
    here = os.path.dirname(__file__)
    src = None
    for c in ["Input_address_2.xlsx", "input.xlsx", "input.csv"]:
        p = os.path.join(here, c)
        if os.path.exists(p):
            src = p; break
    if not src:
        raise FileNotFoundError("Place Input_address_2.xlsx (or input.xlsx/csv) next to this script.")
    df = pd.read_excel(src) if src.endswith(".xlsx") else pd.read_csv(src)
    df.columns = df.columns.str.strip().str.lower()
    for c in ["address1","address2","address3","city","state","pincode"]:
        if c not in df.columns: df[c]=None
    df["pincode"] = df["pincode"].apply(norm_pin)
    df = df[["address1","address2","address3","city","state","pincode"]].copy()
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.input_addresses RESTART IDENTITY CASCADE"))
        df.to_sql("input_addresses", con, schema="av", if_exists="append", index=False)
    print(f"Loaded {len(df):,} input rows.")

if __name__ == "__main__":
    main()
