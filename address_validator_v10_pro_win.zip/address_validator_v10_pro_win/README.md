
# Address Validator v10_pro (Windows package)

- Full flowchart logic (PIN present/absent, ambiguity, mismatches)
- Batch processing (default 10,000)
- City/State/Overall confidence + confidence_level
- Locality extracted ONLY from input
- Excel outputs (input columns first); DB output normalized
- Primary keys: input_id (on input), validation_id (on output)

## Quick Start (with sample files)
1. Create schema and load sample data into Postgres:
   ```sql
   \i schema.sql;
   ```
   Then use the sample CSV/XLSX to populate `av.master_ref` and `av.input_addresses`
   (see `samples/LOAD_SAMPLES.sql`).

2. Edit `db_config.py` and set your Postgres DSN.

3. Run:
   ```bash
   python -m address_validator_v10_pro_win.main
   ```

Outputs:
- Per batch: `/mnt/data/validation_results_part<i>_v10_pro.xlsx`
- Merged: `/mnt/data/validation_results_all_v10_pro.xlsx`
