
import pandas as pd
from dataclasses import dataclass
from typing import Optional, List, Dict
from .text_utils import clean_text, token_set_sim, extract_pin
from .state_maps import load_state_mappings, normalize_state
from .constants import CITY_THRESHOLD, STATE_THRESHOLD, W_PIN, W_CITY, W_STATE, HIGH_CONF, MED_CONF, CITY_ALIASES
from .locality import extract_locality

def normalize_city(s:str)->str:
    s = clean_text(s)
    toks = [CITY_ALIASES.get(t,t) for t in s.split()]
    return " ".join(toks).title()

def conf_level(score:float)->str:
    if score >= HIGH_CONF: return "High"
    if score >= MED_CONF:  return "Medium"
    return "Low"

@dataclass
class Decision:
    status: str
    reason: str
    confidence: float
    confidence_level: str
    city_confidence: float
    state_confidence: float
    chosen: Dict
    suggestions: List[Dict]

class AddressValidator:
    def __init__(self, master_df: pd.DataFrame, state_csv_path: Optional[str]=None):
        self.master = master_df.copy()
        self.master["pincode"] = self.master["pincode"].astype(str).str.extract(r'(\d{6})')
        self.master["city_norm"]  = self.master["city"].apply(normalize_city)
        st_to_abbr, abbr_to_st = load_state_mappings(state_csv_path)
        self.state_to_abbr = st_to_abbr
        self.abbr_to_state = abbr_to_st
        self.master["state_norm"] = self.master["state"].apply(lambda s: normalize_state(s, self.state_to_abbr, self.abbr_to_state))
        self.by_pin = {k:v for k,v in self.master.groupby("pincode")}
        self.city_index = self.master.drop_duplicates(subset=["city_norm","state_norm"])

    def score(self, city_sim:float, state_sim:float, pin_match:bool)->float:
        return W_CITY*city_sim + W_STATE*state_sim + W_PIN*(1.0 if pin_match else 0.0)

    def _derive_candidates_from_pin(self, pin:str)->List[Dict]:
        if pin not in self.by_pin: return []
        df = self.by_pin[pin][["pincode","city_norm","state_norm"]].drop_duplicates()
        return [dict(pincode=r.pincode, city=r.city_norm, state=r.state_norm, country="India")
                for r in df.itertuples(index=False)]

    def _guess_city_from_text(self, addr_clean:str)->List[str]:
        tokens = set(addr_clean.title().split())
        present = self.city_index[self.city_index["city_norm"].isin(tokens)]["city_norm"].unique().tolist()
        return present

    def decide(self, addr_row: Dict)->Decision:
        addr_raw = " ".join([str(x) for x in [addr_row.get("address1"), addr_row.get("address2"), addr_row.get("address3")] if x and str(x).lower()!="nan"]).strip()
        addr_clean = clean_text(addr_raw)
        pin = extract_pin(addr_raw) or extract_pin(addr_row.get("pincode"))
        inp_city  = normalize_city(addr_row.get("city") or "")
        inp_state = normalize_state(addr_row.get("state") or "", self.state_to_abbr, self.abbr_to_state)

        if pin:
            if pin in self.by_pin:
                cands = self._derive_candidates_from_pin(pin)
                best=None; best_s=-1; best_city_sim=0; best_state_sim=0
                for c in cands:
                    cs = token_set_sim(c["city"], inp_city) if inp_city else 0.0
                    ss = token_set_sim(c["state"], inp_state) if inp_state else 0.0
                    s = self.score(cs, ss, True)
                    if s>best_s:
                        best, best_s, best_city_sim, best_state_sim = c, s, cs, ss
                if len({c["city"] for c in cands})>1 and (best_city_sim < CITY_THRESHOLD):
                    return Decision("FLAG","Ambiguous: pincode maps to multiple cities; city in input does not clearly match",
                                    best_s, conf_level(best_s), best_city_sim, best_state_sim, best, cands)
                if inp_city and best["city"] and token_set_sim(best["city"], inp_city) < 0.40:
                    return Decision("FLAG","City mismatch with master for the given pincode", best_s, conf_level(best_s),
                                    best_city_sim, best_state_sim, best, cands)
                if inp_state and best["state"] and token_set_sim(best["state"], inp_state) < 0.50:
                    return Decision("FLAG","State mismatch with master for the given pincode", best_s, conf_level(best_s),
                                    best_city_sim, best_state_sim, best, cands)
                return Decision("OK","Pincode found in DB", best_s, conf_level(best_s), best_city_sim, best_state_sim, best, cands)
            else:
                return Decision("FLAG","6-digit pincode not in India DB (Foreign/Invalid)",
                                0.0,"Low",0.0,0.0,{"pincode":pin,"city":inp_city or None,"state":inp_state or None,"country":addr_row.get("country") or None},[])

        if not inp_city:
            guesses = self._guess_city_from_text(addr_clean)
            if len(guesses)==1:
                inp_city = guesses[0]
            elif len(guesses)>1:
                return Decision("FLAG","No pincode and multiple possible cities detected in text",0.0,"Low",0.0,0.0,
                                {"pincode":None,"city":None,"state":inp_state or None,"country":None},[{"city":g} for g in guesses])

        city_rows = self.city_index[self.city_index["city_norm"]==inp_city] if inp_city else pd.DataFrame()
        if not city_rows.empty:
            states_for_city = city_rows["state_norm"].unique().tolist()
            if inp_state:
                state_sim = max([token_set_sim(s, inp_state) for s in states_for_city]) if states_for_city else 0.0
                s = self.score(1.0, state_sim, False)
                if state_sim < STATE_THRESHOLD:
                    return Decision("FLAG","City found but state mismatch / ambiguous", s, conf_level(s), 1.0, state_sim,
                                    {"pincode":None,"city":inp_city,"state":None,"country":"India"},
                                    [{"city":inp_city,"state":st,"country":"India"} for st in states_for_city])
                return Decision("OK","City & State validated without pincode", s, conf_level(s), 1.0, state_sim,
                                {"pincode":None,"city":inp_city,"state":inp_state,"country":"India"},
                                [{"city":inp_city,"state":st,"country":"India"} for st in states_for_city])
            else:
                if len(states_for_city)>1:
                    return Decision("FLAG","Ambiguous: same city name exists in multiple states",0.0,"Low",1.0,0.0,
                                    {"pincode":None,"city":inp_city,"state":None,"country":"India"},
                                    [{"city":inp_city,"state":st,"country":"India"} for st in states_for_city])
                else:
                    s = self.score(1.0,1.0,False)
                    return Decision("OK","City uniquely maps to a single state", s, conf_level(s), 1.0, 1.0,
                                    {"pincode":None,"city":inp_city,"state":states_for_city[0],"country":"India"},[])

        if inp_state:
            if inp_state in self.master["state_norm"].unique().tolist():
                s = self.score(0.0,1.0,False)
                return Decision("OK","State recognized; city unknown", s, conf_level(s), 0.0, 1.0,
                                {"pincode":None,"city":inp_city or None,"state":inp_state,"country":"India"},[])
            else:
                return Decision("FLAG","Provided state not recognized in DB",0.0,"Low",0.0,0.0,
                                {"pincode":None,"city":inp_city or None,"state":inp_state,"country":None},[])

        return Decision("FLAG","No pincode and could not derive city/state",0.0,"Low",0.0,0.0,
                        {"pincode":None,"city":None,"state":None,"country":None},[])
