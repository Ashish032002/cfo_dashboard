
import pandas as pd
from sqlalchemy import text
from tqdm import tqdm
from .db_config import get_db_connection
from .flow_engine import AddressValidator
from .locality import extract_locality

INPUT_TABLE  = "av.input_addresses"
MASTER_TABLE = "av.master_ref"
OUTPUT_TABLE = "av.validation_result_final"
BATCH_SIZE   = 10000

def ensure_schema_and_ids(engine):
    with engine.begin() as con:
        con.execute(text(f"""
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_schema='av' AND table_name='input_addresses' AND column_name='input_id'
          ) THEN
            ALTER TABLE {INPUT_TABLE} ADD COLUMN input_id BIGSERIAL PRIMARY KEY;
          END IF;
        END $$;
        """))
        con.execute(text(f"DROP TABLE IF EXISTS {OUTPUT_TABLE} CASCADE;"))
        con.execute(text(f"""
        CREATE TABLE {OUTPUT_TABLE} (
          validation_id BIGSERIAL PRIMARY KEY,
          input_id BIGINT,
          city TEXT, state TEXT, pincode TEXT, country TEXT,
          derived_city TEXT, derived_state TEXT, derived_pincode TEXT, derived_country TEXT,
          city_confidence NUMERIC, state_confidence NUMERIC, overall_confidence NUMERIC,
          confidence_level TEXT, status TEXT, reason TEXT, locality TEXT, suggestions JSONB
        );
        """))

def run():
    print("Starting Address Validator v10_pro (Batch Mode)...")
    eng = get_db_connection()
    ensure_schema_and_ids(eng)
    with eng.begin() as con:
        master = pd.read_sql(f"SELECT pincode, state, city FROM {MASTER_TABLE}", con)
        inputs = pd.read_sql(f"SELECT * FROM {INPUT_TABLE} ORDER BY input_id", con)

    validator = AddressValidator(master)
    chunks = [inputs[i:i+BATCH_SIZE] for i in range(0, len(inputs), BATCH_SIZE)]
    all_outputs = []

    for i, batch in enumerate(chunks, start=1):
        print(f"Processing batch {i}/{len(chunks)} ({len(batch)} records)...")
        batch_results = []
        for r in tqdm(batch.to_dict(orient="records")):
            decision = validator.decide(r)
            batch_results.append({
                "input_id": r.get("input_id"),
                "city": r.get("city"), "state": r.get("state"),
                "pincode": r.get("pincode"), "country": r.get("country"),
                "derived_city": decision.chosen.get("city"),
                "derived_state": decision.chosen.get("state"),
                "derived_pincode": decision.chosen.get("pincode"),
                "derived_country": decision.chosen.get("country"),
                "city_confidence": round(float(decision.city_confidence or 0.0),3),
                "state_confidence": round(float(decision.state_confidence or 0.0),3),
                "overall_confidence": round(float(decision.confidence or 0.0),3),
                "confidence_level": decision.confidence_level,
                "status": decision.status,
                "reason": decision.reason,
                "locality": extract_locality(" ".join([str(r.get('address1') or ''), str(r.get('address2') or ''), str(r.get('address3') or '')]), 
                                             r.get('city'), r.get('state'), r.get('pincode')),
                "suggestions": decision.suggestions
            })
        out_df = pd.DataFrame(batch_results)
        with eng.begin() as con:
            out_df.to_sql(OUTPUT_TABLE.split('.')[-1], con, schema=OUTPUT_TABLE.split('.')[0], if_exists='append', index=False)
        excel_df = batch.merge(out_df, on="input_id", how="left")
        xlsx_path = f"/mnt/data/validation_results_part{i}_v10_pro.xlsx"
        excel_df.to_excel(xlsx_path, index=False)
        print(f"✅ Saved {xlsx_path}")
        all_outputs.append(excel_df)

    if all_outputs:
        final_path = "/mnt/data/validation_results_all_v10_pro.xlsx"
        pd.concat(all_outputs).to_excel(final_path, index=False)
        print(f"✅ All batches merged: {final_path}")

if __name__ == "__main__":
    run()
