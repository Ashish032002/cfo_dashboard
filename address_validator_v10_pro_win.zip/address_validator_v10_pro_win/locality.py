
import re
from .text_utils import clean_text
from .constants import STOP_WORDS, LOCALITY_CUES

CUE_RE = re.compile(r'\b(' + '|'.join(re.escape(c) for c in LOCALITY_CUES) + r')\b', re.IGNORECASE)

def extract_locality(addr_raw, city=None, state=None, pincode=None):
    if not addr_raw: return None
    base = clean_text(addr_raw)
    for token in [str(city or ''), str(state or ''), str(pincode or '')]:
        t = clean_text(token)
        if t:
            base = base.replace(t, ' ')
    base = re.sub(r'\s+', ' ', base).strip()

    m = CUE_RE.search(addr_raw or '')
    if m:
        words = (addr_raw or '').split()
        idx = 0
        for i,w in enumerate(words):
            if w.lower() == m.group(1).lower():
                idx=i; break
        start = max(0, idx-3); end = min(len(words), idx+6)
        return " ".join(words[start:end]).strip()

    toks = [t for t in base.split() if t not in STOP_WORDS and not t.isdigit()]
    toks = sorted(set(toks), key=lambda x:(-len(x), x))
    return " ".join(toks[:5]) if toks else None
