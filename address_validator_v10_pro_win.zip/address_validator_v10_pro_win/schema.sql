
CREATE SCHEMA IF NOT EXISTS av;
CREATE TABLE IF NOT EXISTS av.master_ref (pincode TEXT, state TEXT, city TEXT);
CREATE TABLE IF NOT EXISTS av.input_addresses (
  address1 TEXT, address2 TEXT, address3 TEXT,
  city TEXT, state TEXT, pincode TEXT, country TEXT
);
