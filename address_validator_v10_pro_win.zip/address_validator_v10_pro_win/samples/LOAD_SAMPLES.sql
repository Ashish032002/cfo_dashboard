
-- Run after schema.sql
\copy av.master_ref(pincode,state,city) FROM 'samples/master_data.csv' WITH CSV HEADER;
-- For input, you can use \copy with CSV after saving the XLSX as CSV in Excel, or load via Python.
