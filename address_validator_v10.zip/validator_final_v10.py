
import os, re, json, pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

try:
    from rapidfuzz import fuzz, process
    def sim(a,b): return fuzz.token_set_ratio(a or '', b or '')/100
except Exception:
    import difflib
    def sim(a,b): return difflib.SequenceMatcher(None, (a or '').lower(), (b or '').lower()).ratio()
    process = None

# thresholds
CITY_THRESHOLD  = 0.5
STATE_THRESHOLD = 0.6

STOP_WORDS = {
    "division","city","district","region","circle","zone","south","north",
    "east","west","office","so","s.o","bo","b.o","po","p.o","head","branch",
    "rms","ho","do","co","post","nodal","sub","urban","rural","taluk","mandal",
    "central","new","old"
}
CITY_ALIASES = {
    "bombay":"mumbai","bengaluru":"bangalore","bengluru":"bangalore",
    "benglore":"bangalore","calcutta":"kolkata","trivandrum":"thiruvananthapuram",
    "kochi":"cochin","cochin":"kochi","vadodara":"baroda","baroda":"vadodara",
    "pondicherry":"puducherry","nasik":"nashik","gurgaon":"gurugram",
    "gurugram":"gurgaon","ahmadabad":"ahmedabad"
}
LOCALITY_HINTS = [
    r"\bsector\s+\d+\b", r"\bphase\s+\d+\b", r"\bblock\s+[a-z0-9]+\b",
    r"\broad\b", r"\bstreet\b", r"\bmarg\b", r"\bnagar\b", r"\bcolony\b",
    r"\blayout\b", r"\barea\b", r"\bward\s+\d+\b", r"\bbazar\b", r"\bmarket\b",
]

def strip_accents(s):
    import unicodedata
    return ''.join(ch for ch in unicodedata.normalize('NFKD', str(s)) if not unicodedata.combining(ch))

def clean_text(s):
    s = strip_accents(str(s or '')).lower()
    s = re.sub(r'[^\w\s]', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def normalize_city(s):
    s = clean_text(s)
    toks = [CITY_ALIASES.get(t, t) for t in s.split() if t not in STOP_WORDS]
    return ' '.join(toks).strip().title()

def extract_pin(txt):
    if not txt: return None
    m = re.search(r'(?<!\d)(\d{6})(?!\d)', str(txt))
    return m.group(1) if m else None

def extract_locality_from_address(addr, city=None, state=None, pincode=None):
    if not addr: return None
    txt = " " + str(addr) + " "
    if pincode:
        txt = re.sub(rf"\b{pincode}\b", " ", txt, flags=re.I)
    for item in [city, state]:
        if item:
            for p in str(item).split():
                txt = re.sub(rf"\b{re.escape(p)}\b", " ", txt, flags=re.I)
    txt = clean_text(txt)
    for pat in LOCALITY_HINTS:
        m = re.search(pat, txt, flags=re.I)
        if m:
            tokens = txt.split()
            try:
                idx = tokens.index(m.group(0).lower())
            except ValueError:
                continue
            start = max(0, idx-3); end = min(len(tokens), idx+4)
            return " ".join(tokens[start:end]).title()
    tokens = [t for t in txt.split() if t not in STOP_WORDS and not t.isdigit()]
    tokens = sorted(set(tokens), key=lambda x: (-len(x), x))
    return " ".join(tokens[:3]).title() if tokens else None

def load_state_mappings():
    base = os.path.join(os.path.dirname(__file__), "datasets")
    for name in ["abbreviation_list 1.csv", "abbreviation_list.csv"]:
        path = os.path.join(base, name)
        if os.path.exists(path):
            df = pd.read_csv(path)
            break
    else:
        raise FileNotFoundError("State abbreviation CSV not found in datasets/.")
    df.columns = df.columns.str.strip().str.title()
    df["State"] = df["State"].astype(str).str.strip().str.title()
    df["Abbreviation"] = df["Abbreviation"].astype(str).str.strip().str.upper()
    state_to_abbr = dict(zip(df["State"], df["Abbreviation"]))
    abbr_to_state = dict(zip(df["Abbreviation"], df["State"]))
    return state_to_abbr, abbr_to_state

def normalize_state(s, state_to_abbr, abbr_to_state):
    if s is None or (isinstance(s, float) and pd.isna(s)): return None
    s_clean = clean_text(str(s)).replace('.', '').upper().strip()
    if s_clean in abbr_to_state:
        return abbr_to_state[s_clean]
    st = s_clean.title()
    if st in state_to_abbr:
        return st
    if 'process' in globals() and process is not None:
        best, score, _ = process.extractOne(st, list(state_to_abbr.keys()))
        return best if score >= 85 else st
    return st

def build_indexes(master, state_to_abbr, abbr_to_state):
    m = master.copy()
    m["city_norm"]  = m["city"].apply(normalize_city)
    m["state_norm"] = m["state"].apply(lambda s: normalize_state(s, state_to_abbr, abbr_to_state))
    by_pin   = {k:v for k,v in m.groupby("pincode")}
    by_city  = {k:v for k,v in m.groupby("city_norm")}
    by_state = {k:v for k,v in m.groupby("state_norm")}
    return by_pin, by_city, by_state

def compute_conf(city_conf, state_conf): return 0.6*city_conf + 0.4*state_conf

def _top_k_as_json(df, k=3):
    # return [{"city":..., "state":..., "pincode":..., "score":...}, ...]
    out = []
    for _, r in df.head(k).iterrows():
        out.append({
            "city": str(r["city"]),
            "state": str(r["state"]),
            "pincode": str(r["pincode"]),
            "score": round(float(r["score"]), 3)
        })
    return json.dumps(out, ensure_ascii=False)

def validate_df(df, master_by_pin, master_by_city, master_by_state, state_to_abbr, abbr_to_state, start_out_id):
    results=[]; out_id=start_out_id
    for _,r in df.iterrows():
        input_id = r.get("id")
        a1,a2,a3 = r.get("address1"), r.get("address2"), r.get("address3")
        addr_raw = " ".join([str(x) for x in [a1,a2,a3] if x and str(x).lower()!='nan']).strip()

        pin = extract_pin(addr_raw) or extract_pin(r.get("pincode"))
        in_city_txt  = r.get("city")
        in_state_txt = r.get("state")
        city_in  = normalize_city(in_city_txt)
        state_in = normalize_state(in_state_txt, state_to_abbr, abbr_to_state)

        best_city=None; best_state=None; city_conf=0.0; state_conf=0.0
        flag="No"; reason=[]; pincode_status="NotFound"
        ambiguity_type="none"; possible_json=None

        if pin:
            if pin in master_by_pin:
                pincode_status="Found"
                dfp = master_by_pin[pin].copy()
                dfp["city_sim"]  = dfp["city_norm"].apply(lambda x: sim(x, city_in))
                dfp["state_sim"] = dfp["state_norm"].apply(lambda x: sim(x, state_in))
                dfp["score"] = 0.6*dfp["city_sim"] + 0.4*dfp["state_sim"]
                top = dfp.sort_values("score", ascending=False)

                # Ambiguity classification
                multi_city = top["city_norm"].nunique() > 1
                multi_state = top["state_norm"].nunique() > 1
                if multi_city and multi_state:
                    ambiguity_type="multi-city-state"
                elif multi_city:
                    ambiguity_type="multi-city"
                elif multi_state:
                    ambiguity_type="multi-state"
                else:
                    ambiguity_type="single"

                # Store top-3 possible addresses (city/state/pin + score)
                possible_json = _top_k_as_json(top, 3)

                best = top.iloc[0]
                best_city, best_state = str(best["city"]), str(best["state"])
                city_conf, state_conf = float(best["city_sim"]), float(best["state_sim"])

                if not (city_conf>=CITY_THRESHOLD and state_conf>=STATE_THRESHOLD):
                    flag="Yes"; reason.append("City/State weak match for valid pincode")
                if ambiguity_type in ("multi-city","multi-state","multi-city-state"):
                    flag="Yes"; reason.append(f"Ambiguity: {ambiguity_type}")
            else:
                pincode_status="NotInDB"
                flag="Yes"; reason.append("6-digit pincode but not present in master_ref")
        else:
            flag="Yes"; reason.append("No pincode found")
            if city_in and city_in in master_by_city:
                dfc = master_by_city[city_in].copy()
                dfc["state_sim"] = dfc["state_norm"].apply(lambda x: sim(x, state_in))
                dfc["score"] = dfc["state_sim"]
                top = dfc.sort_values("score", ascending=False)
                possible_json = _top_k_as_json(top, 3)
                best = top.iloc[0]
                best_city, best_state = str(best["city"]), str(best["state"])
                city_conf, state_conf = 1.0, float(best["state_sim"])
                ambiguity_type = "single" if top["state_norm"].nunique()==1 else "multi-state"
                if ambiguity_type != "single":
                    flag="Yes"; reason.append("Ambiguity: multi-state (city without pin)")
                reason.append("Derived from city")
            elif state_in and state_in in master_by_state:
                dfs = master_by_state[state_in].copy()
                # provide top-3 cities by similarity to input city text (if any)
                if in_city_txt:
                    dfs["city_sim"] = dfs["city_norm"].apply(lambda x: sim(x, city_in))
                else:
                    dfs["city_sim"] = 0
                dfs["score"] = dfs["city_sim"]
                top = dfs.sort_values("score", ascending=False)
                possible_json = _top_k_as_json(top, 3)
                best_city, best_state = in_city_txt, state_in
                city_conf, state_conf = (float(top.iloc[0]["city_sim"]) if len(top)>0 else 0.0), 1.0
                ambiguity_type = "single"
                reason.append("State present in master; city not fully verified")
            else:
                reason.append("City/State not verifiable")
                ambiguity_type = "none"

        overall = compute_conf(city_conf, state_conf)
        level = "High" if overall>=0.8 else ("Medium" if overall>=0.6 else "Low")

        final_city  = best_city  or city_in
        final_state = best_state or state_in
        locality = extract_locality_from_address(addr_raw, city=final_city, state=final_state, pincode=pin)

        results.append({
            "out_id": out_id,
            "input_id": int(input_id) if input_id is not None and pd.notna(input_id) else None,
            "Address": addr_raw,
            "City": final_city,
            "State": final_state,
            "Pincode": pin,
            "Country": "India",
            "City_Confidence": round(city_conf,3),
            "State_Confidence": round(state_conf,3),
            "Overall_Confidence": round(overall,3),
            "Confidence_Level": level,
            "Flag": "Yes" if flag=="Yes" else "No",
            "Reason": "; ".join(reason) if reason else "",
            "Locality": locality,
            "Ambiguity_Type": ambiguity_type,
            "Possible_Addresses": possible_json,
            "_in_address1": a1, "_in_address2": a2, "_in_address3": a3,
            "_in_city": in_city_txt, "_in_state": in_state_txt, "_in_pincode": r.get("pincode"),
            "_pincode_status": pincode_status
        })
        out_id += 1
    return pd.DataFrame(results), out_id

def main():
    print("Starting Address Validator v10 ...")
    eng = get_db_connection()
    state_to_abbr, abbr_to_state = load_state_mappings()

    with eng.begin() as con:
        master = pd.read_sql("SELECT city,state,pincode,office_name FROM av.master_ref", con)
        inp    = pd.read_sql("SELECT * FROM av.input_addresses ORDER BY id", con)

    by_pin, by_city, by_state = build_indexes(master, state_to_abbr, abbr_to_state)

    with eng.begin() as con:
        con.execute(text("DROP TABLE IF EXISTS av.validation_result_final CASCADE"))
        con.execute(text(\"\"\"
            CREATE TABLE av.validation_result_final (
                out_id BIGINT PRIMARY KEY,
                input_id BIGINT,
                address1 TEXT, city TEXT, state TEXT, pincode TEXT, country TEXT,
                city_confidence NUMERIC, state_confidence NUMERIC,
                overall_confidence NUMERIC, confidence_level TEXT,
                flag TEXT, reason TEXT, locality TEXT,
                ambiguity_type TEXT,
                possible_addresses JSONB
            )
        \"\"\"))

    out_id = 1
    batch_size = 10000
    total = len(inp)
    batches = [inp[i:i+batch_size] for i in range(0, total, batch_size)]

    for b,chunk in enumerate(batches, 1):
        df_part, out_id = validate_df(chunk, by_pin, by_city, by_state, state_to_abbr, abbr_to_state, out_id)

        excel_cols_front = ["out_id","input_id","_in_address1","_in_address2","_in_address3","_in_city","_in_state","_in_pincode"]
        core = ["Address","City","State","Pincode","Country",
                "City_Confidence","State_Confidence","Overall_Confidence","Confidence_Level",
                "Flag","Reason","Locality","Ambiguity_Type","Possible_Addresses","_pincode_status"]
        df_x = df_part[excel_cols_front + core]
        out_x = f"validated_output_part{b}.xlsx"
        df_x.to_excel(out_x, index=False)
        print(f"Saved {out_x}")

        db_df = df_part.copy().rename(columns={"Address":"address1"})
        drop_cols = ["_in_address1","_in_address2","_in_address3","_in_city","_in_state","_in_pincode","_pincode_status"]
        db_df = db_df.drop(columns=drop_cols).fillna("")

        with eng.begin() as con:
            for _,row in db_df.iterrows():
                con.execute(text(\"\"\"
                    INSERT INTO av.validation_result_final
                    (out_id,input_id,address1,city,state,pincode,country,
                     city_confidence,state_confidence,overall_confidence,confidence_level,
                     flag,reason,locality,ambiguity_type,possible_addresses)
                    VALUES(:oid,:iid,:a,:c,:s,:p,:co,:cc,:sc,:oc,:cl,:f,:r,:l,:at,:pa)
                \"\"\"), {
                    "oid": int(row["out_id"]),
                    "iid": None if row["input_id"]=="" else int(row["input_id"]) if str(row["input_id"]).isdigit() else None,
                    "a": row["address1"],
                    "c": row["City"],
                    "s": row["State"],
                    "p": row["Pincode"],
                    "co": row["Country"],
                    "cc": row["City_Confidence"],
                    "sc": row["State_Confidence"],
                    "oc": row["Overall_Confidence"],
                    "cl": row["Confidence_Level"],
                    "f": row["Flag"],
                    "r": row["Reason"],
                    "l": row["Locality"],
                    "at": row["Ambiguity_Type"],
                    "pa": row["Possible_Addresses"],
                })
        print(f"Batch {b} inserted into DB ({len(db_df)} rows).")

    print("All batches processed successfully!")

if __name__ == "__main__":
    main()
