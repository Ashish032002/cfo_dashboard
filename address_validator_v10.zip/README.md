
# Address Validator v10 (Ambiguity-aware)

## What’s new vs v9
- **Ambiguity classified**: `single`, `multi-city`, `multi-state`, `multi-city-state`.
- **Top-3 possible addresses** (city/state/pincode + score) saved as JSON in Excel and DB.
- **Locality** still extracted only from input address (no office influence).
- **Batching** stays 10,000 rows → Excel + DB insert per batch.
- **PKs**: `av.input_addresses.id`, and `av.validation_result_final.out_id` with `input_id` for linkage.

## Run order
1. `python create_schema.py`
2. Place `pincode_master.xlsx` **or** `master_data.csv` (same folder), then run:
   `python upload_master_data.py`
3. Place `Input_address_2.xlsx`, then run:
   `python upload_input_data.py`
4. Validate in batches:
   `python validator_final_v10.py`

## Inspect in psql
```sql
\c addressdb;
\dt av.*;
SELECT out_id, input_id, city, state, pincode, flag, ambiguity_type, reason
FROM av.validation_result_final
ORDER BY out_id
LIMIT 20;
```

## Notes
- Matching score uses **city/state only** (no office).  
- Confidence: `0.6*City_Confidence + 0.4*State_Confidence`.
- Excel puts the original input columns in front to aid manual QA.
