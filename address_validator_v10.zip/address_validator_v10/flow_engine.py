
import pandas as pd
from dataclasses import dataclass
from typing import Dict, List
from .text_utils import clean_text, token_set_sim, extract_pin
from .state_maps import load_state_mappings, normalize_state
from .constants import W_PIN, W_CITY, W_STATE, HIGH_CONF, MED_CONF, CITY_ALIASES

def normalize_city(s:str)->str:
    s = clean_text(s)
    toks = [CITY_ALIASES.get(t,t) for t in s.split()]
    return " ".join(toks).title()

def conf_level(score:float)->str:
    if score >= HIGH_CONF: return "High"
    if score >= MED_CONF:  return "Medium"
    return "Low"

@dataclass
class Decision:
    status: str
    reason: str
    confidence: float
    confidence_level: str
    city_confidence: float
    state_confidence: float
    chosen: Dict
    suggestions: List[Dict]

class AddressValidator:
    def __init__(self, master_df, state_csv_path=None):
        self.master = master_df.copy()
        self.master["pincode"] = self.master["pincode"].astype(str).str.extract(r'(\d{6})')
        self.master["city_norm"]  = self.master["city"].apply(normalize_city)
        st_to_abbr, abbr_to_st = load_state_mappings(state_csv_path)
        self.state_to_abbr = st_to_abbr
        self.abbr_to_state = abbr_to_st
        self.master["state_norm"] = self.master["state"].apply(lambda s: normalize_state(s, self.state_to_abbr, self.abbr_to_state))
        self.by_pin = {k:v for k,v in self.master.groupby("pincode")}

    def score(self, city_sim, state_sim, pin_match):
        return W_CITY*city_sim + W_STATE*state_sim + W_PIN*(1.0 if pin_match else 0.0)

    def decide(self, addr_row: Dict)->Decision:
        addr_raw = " ".join([str(x) for x in [addr_row.get("address1"), addr_row.get("address2"), addr_row.get("address3")] if x and str(x).lower()!="nan"]).strip()
        pin = extract_pin(addr_raw) or extract_pin(addr_row.get("pincode"))
        inp_city  = normalize_city(addr_row.get("city") or "")
        inp_state = normalize_state(addr_row.get("state") or "", self.state_to_abbr, self.abbr_to_state)

        if pin and pin in self.by_pin:
            dfp = self.by_pin[pin]
            dfp["city_sim"] = dfp["city_norm"].apply(lambda x: token_set_sim(x, inp_city))
            dfp["state_sim"] = dfp["state_norm"].apply(lambda x: token_set_sim(x, inp_state))
            dfp["score"] = dfp.apply(lambda x: self.score(x.city_sim,x.state_sim,True), axis=1)
            best = dfp.sort_values("score",ascending=False).iloc[0]
            return Decision(
                status="OK",
                reason="Pincode found in India DB",
                confidence=float(best.score),
                confidence_level=conf_level(best.score),
                city_confidence=float(best.city_sim),
                state_confidence=float(best.state_sim),
                chosen={"pincode":pin,"city":best.city_norm,"state":best.state_norm,"country":"India"},
                suggestions=dfp[["pincode","city_norm","state_norm"]].drop_duplicates().to_dict("records")
            )
        else:
            return Decision(
                status="FLAG",
                reason="Pincode missing or invalid",
                confidence=0.0,
                confidence_level="Low",
                city_confidence=0.0,
                state_confidence=0.0,
                chosen={"pincode":pin,"city":inp_city,"state":inp_state,"country":None},
                suggestions=[]
            )
