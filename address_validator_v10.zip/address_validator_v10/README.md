
# Address Validator v10 (Batch Processing + Confidence Enhancements)

✅ Fully compliant with flowchart logic  
✅ Batch processing (10,000 records at a time)  
✅ Writes each batch to Excel and inserts into DB before next batch  
✅ Combines all outputs into one final Excel  
✅ Includes city/state/overall confidence scores  
✅ Input address columns appear first in Excel for validation  
✅ Primary keys ensured (`input_id`, `validation_id`)

Run via:
```bash
python -m address_validator_v10.main
```
