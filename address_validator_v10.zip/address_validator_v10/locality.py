def extract_locality(a,b,c,d): return None
