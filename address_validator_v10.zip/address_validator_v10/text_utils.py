import re
def clean_text(s): return str(s or '').lower().strip()
def token_set_sim(a,b): return 1.0 if a==b else 0.0
def extract_pin(t): m=re.search(r'(\d{6})',str(t)); return m.group(1) if m else None
