
import os
from sqlalchemy import create_engine

def get_db_connection():
    host = os.getenv("PGHOST", "localhost")
    port = int(os.getenv("PGPORT", "5432"))
    db   = os.getenv("PGDATABASE", "addressdb")
    user = os.getenv("PGUSER", "postgres")
    pwd  = os.getenv("PGPASSWORD", "postgres")
    url = f"postgresql+psycopg2://{user}:{pwd}@{host}:{port}/{db}"
    echo = os.getenv("SQL_ECHO", "0") == "1"
    return create_engine(url, pool_pre_ping=True, echo=echo)
