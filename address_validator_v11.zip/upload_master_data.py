
import os
import pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

def main():
    eng = get_db_connection()
    candidates = ["pincode_master.xlsx","master_data.csv","master_data.xlsx"]
    src=None
    for c in candidates:
        p=os.path.join(os.path.dirname(__file__),c)
        if os.path.exists(p): src=p; break
    if not src:
        raise FileNotFoundError("Place pincode_master.xlsx or master_data.csv next to this script.")
    df = pd.read_excel(src) if src.endswith('.xlsx') else pd.read_csv(src)
    cols = {c.lower().strip(): c for c in df.columns}
    def pick(*names):
        for n in names:
            if n in cols: return cols[n]
        return None
    city_col   = pick("divisionname","city","division","office","officename","office_name")
    state_col  = pick("statename","state")
    pin_col    = pick("pincode","pin","pin code","pincode6")
    office_col = pick("office_name","officename","office","branch","sub office")
    if not (city_col and state_col and pin_col):
        raise ValueError(f"Could not detect core columns. Found: {df.columns.tolist()}" )
    m = pd.DataFrame({
        "city": df[city_col].astype(str).str.strip().str.title(),
        "state": df[state_col].astype(str).str.strip().str.title(),
        "pincode": df[pin_col].astype(str).str.extract(r'(\d{6})', expand=False),
        "office_name": (df[office_col] if office_col else "").astype(str).str.strip().str.title()
    }).dropna(subset=["pincode"])
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.master_ref RESTART IDENTITY CASCADE"))
        m.to_sql("master_ref", con, schema="av", if_exists="append", index=False)
    print(f"Loaded {len(m):,} rows into av.master_ref from {os.path.basename(src)}")

if __name__ == "__main__":
    main()
