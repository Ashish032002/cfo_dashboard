
# Address Validator v11

Run in order:
1. `python create_schema.py`
2. `python upload_master_data.py`
3. `python upload_input_data.py`
4. `python validator_final_v11.py`

- Validates in batches of 10,000, writes Excel per batch, inserts each batch into DB.
- Locality is extracted from input address only.
- State abbreviations expanded via `datasets/abbreviation_list 1.csv`.
