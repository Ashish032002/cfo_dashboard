import os, re, unicodedata
import pandas as pd
from sqlalchemy import text
from rapidfuzz import fuzz, process
from tqdm import tqdm
from db_config import get_db_connection

CITY_THRESHOLD = 0.5
STATE_THRESHOLD = 0.6

STOP_WORDS = {
    "division","city","district","region","circle","zone","south","north",
    "east","west","office","so","s.o","bo","b.o","po","p.o","head","branch",
    "rms","ho","do","co","post","nodal","sub","urban","rural","taluk","mandal",
    "east","west","north","south","central","new","old"
}

CITY_ALIASES = {
    "bombay":"mumbai","bengaluru":"bangalore","bengluru":"bangalore",
    "benglore":"bangalore","calcutta":"kolkata","trivandrum":"thiruvananthapuram",
    "kochi":"cochin","cochin":"kochi","vadodara":"baroda","baroda":"vadodara",
    "pondicherry":"puducherry","nasik":"nashik","gurgaon":"gurugram",
    "gurugram":"gurgaon","ahmadabad":"ahmedabad"
}

LOCALITY_HINTS = [
    r"\bsector\s+\d+\b", r"\bphase\s+\d+\b", r"\bblock\s+[a-z0-9]+\b",
    r"\broad\b", r"\bstreet\b", r"\bmarg\b", r"\bnagar\b", r"\bcolony\b",
    r"\blayout\b", r"\barea\b", r"\bward\s+\d+\b", r"\bbazar\b", r"\bmarket\b",
]

def strip_accents(s): 
    return ''.join(ch for ch in unicodedata.normalize('NFKD', str(s)) if not unicodedata.combining(ch))

def clean_text(s):
    s = strip_accents(str(s or '')).lower()
    s = re.sub(r'[^\w\s]', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def normalize_city(s):
    s = clean_text(s)
    toks = [CITY_ALIASES.get(t, t) for t in s.split() if t not in STOP_WORDS]
    return ' '.join(toks).strip().title()

def sim(a,b): 
    return fuzz.token_set_ratio(a or '', b or '')/100

def extract_pin(txt):
    if not txt: return None
    m = re.search(r'(?<!\d)(\d{6})(?!\d)', str(txt))
    return m.group(1) if m else None

def extract_locality_from_address(addr, city=None, state=None, pincode=None):
    if not addr: return None
    txt = " " + str(addr) + " "
    if pincode:
        txt = re.sub(rf"\b{re.escape(str(pincode))}\b", " ", txt, flags=re.I)
    for item in [city, state]:
        if item:
            for p in str(item).split():
                txt = re.sub(rf"\b{re.escape(p)}\b", " ", txt, flags=re.I)
    txt = clean_text(txt)

    for pat in LOCALITY_HINTS:
        m = re.search(pat, txt, flags=re.I)
        if m:
            tokens = txt.split()
            try:
                idx = tokens.index(m.group(0).lower())
            except ValueError:
                continue
            start = max(0, idx-3); end = min(len(tokens), idx+4)
            return " ".join(tokens[start:end]).title()

    tokens = [t for t in txt.split() if t not in STOP_WORDS and not t.isdigit()]
    tokens = sorted(set(tokens), key=lambda x: (-len(x), x))
    return " ".join(tokens[:3]).title() if tokens else None

def load_state_mappings():
    base = os.path.dirname(__file__)
    for name in ["abbreviation_list 1.csv", "abbreviation_list.csv"]:
        p = os.path.join(base, "datasets", name)
        if os.path.exists(p):
            csv_path = p
            break
    else:
        raise FileNotFoundError("State abbreviation CSV not found in datasets/.")

    df = pd.read_csv(csv_path)
    df.columns = df.columns.str.strip().str.title()
    df["State"] = df["State"].astype(str).str.strip().str.title()
    df["Abbreviation"] = df["Abbreviation"].astype(str).str.strip().str.upper()
    state_to_abbr = dict(zip(df["State"], df["Abbreviation"]))
    abbr_to_state = dict(zip(df["Abbreviation"], df["State"]))
    print(f"✅ Loaded {len(state_to_abbr)} state mappings from {os.path.basename(csv_path)}")
    return state_to_abbr, abbr_to_state

def normalize_state(s, state_to_abbr, abbr_to_state):
    if not s: return None
    s_clean = clean_text(str(s)).replace('.', '').upper().strip()
    if s_clean in abbr_to_state:
        return abbr_to_state[s_clean]
    if s_clean.title() in state_to_abbr:
        return s_clean.title()
    best, score, _ = process.extractOne(s_clean.title(), list(state_to_abbr.keys()))
    return best if score >= 85 else s_clean.title()

def validate_batch(df, master_by_pin, batch_no, state_to_abbr, abbr_to_state, start_out_id):
    results=[]
    out_id = start_out_id

    for _,r in tqdm(df.iterrows(), total=len(df), desc=f"Batch {batch_no}"):
        input_id = r.get('id')
        a1, a2, a3 = r.get('address1'), r.get('address2'), r.get('address3')
        addr_raw=" ".join([str(x) for x in [a1,a2,a3] if x and str(x).lower()!='nan']).strip()

        addr_clean=clean_text(addr_raw)
        pin=extract_pin(addr_raw) or extract_pin(r.get('pincode'))
        input_city = r.get('city')
        input_state = r.get('state')
        city_in=normalize_city(input_city)
        state_in=normalize_state(input_state, state_to_abbr, abbr_to_state)
        country="India"

        best_city=None; best_state=None
        city_conf=state_conf=0.0
        pincode_status = "NotFound"
        flag="No"; reason=[]

        if pin:
            if pin in master_by_pin:
                pincode_status = "Found"
                dfp = master_by_pin[pin]
                if 'city_norm' not in dfp.columns:
                    dfp = dfp.copy()
                    dfp['city_norm']=dfp['city'].apply(normalize_city)
                    dfp['state_norm']=dfp['state'].apply(lambda s: normalize_state(s, state_to_abbr, abbr_to_state))
                    master_by_pin[pin]=dfp

                dfp['city_sim']=dfp['city_norm'].apply(lambda x: sim(x, city_in))
                dfp['state_sim']=dfp['state_norm'].apply(lambda x: sim(x, state_in))
                dfp['score']=0.6*dfp['city_sim'] + 0.4*dfp['state_sim']
                top = dfp.sort_values('score', ascending=False).head(5)
                best = top.iloc[0]
                best_city = str(best['city'])
                best_state = str(best['state'])
                city_conf=float(best['city_sim']); state_conf=float(best['state_sim'])

                if not (city_conf>=CITY_THRESHOLD and state_conf>=STATE_THRESHOLD):
                    flag="Yes"; reason.append("City/State weak match for valid pincode")
                if top['city_norm'].nunique()>1 and not input_city:
                    flag="Yes"; reason.append("Ambiguous city for pincode")
            else:
                pincode_status = "NotInDB"
                flag="Yes"; reason.append("6-digit pincode but not present in master_ref")
        else:
            flag="Yes"; reason.append("No pincode found")

        overall=(0.6*city_conf+0.4*state_conf)
        conf_level="High" if overall>=0.8 else ("Medium" if overall>=0.6 else "Low")

        final_city = best_city or city_in
        final_state = best_state or state_in

        locality = extract_locality_from_address(addr_raw, city=final_city, state=final_state, pincode=pin)

        results.append({
            "out_id": out_id,
            "input_id": int(input_id) if input_id is not None and pd.notna(input_id) else None,
            "Address": addr_raw,
            "City": final_city,
            "State": final_state,
            "Pincode": pin,
            "Country": country,
            "City_Confidence": round(city_conf,3),
            "State_Confidence": round(state_conf,3),
            "Overall_Confidence": round(overall,3),
            "Confidence_Level": conf_level,
            "Flag": "Yes" if flag=="Yes" else "No",
            "Reason": "; ".join(reason) if reason else "",
            "Locality": locality,
            "_in_address1": a1, "_in_address2": a2, "_in_address3": a3,
            "_in_city": input_city, "_in_state": input_state, "_in_pincode": r.get('pincode'),
            "_proposed_city_from_pin": best_city, "_proposed_state_from_pin": best_state,
            "_pincode_status": pincode_status
        })
        out_id += 1

    return pd.DataFrame(results), out_id

def main():
    print("🚀 Starting Address Validator v8 ...")
    eng=get_db_connection()

    with eng.begin() as con:
        master=pd.read_sql("SELECT * FROM av.master_ref",con)
        inp=pd.read_sql("SELECT * FROM av.input_addresses ORDER BY id",con)

    state_to_abbr, abbr_to_state = load_state_mappings()

    master_by_pin = {k:v for k,v in master.groupby('pincode')}

    with eng.begin() as con:
        con.execute(text("DROP TABLE IF EXISTS av.validation_result_final CASCADE"))
        con.execute(text("""
            CREATE TABLE av.validation_result_final (
                out_id BIGINT PRIMARY KEY,
                input_id BIGINT,
                address1 TEXT, city TEXT, state TEXT, pincode TEXT, country TEXT,
                city_confidence NUMERIC, state_confidence NUMERIC,
                overall_confidence NUMERIC, confidence_level TEXT,
                flag TEXT, reason TEXT, locality TEXT
            )
        """))
        print("✅ Recreated table av.validation_result_final")

    out_id_start = 1
    chunks=[inp[i:i+10000] for i in range(0,len(inp),10000)]
    for i,ch in enumerate(chunks,1):
        df_part, out_id_start = validate_batch(ch, master_by_pin, i, state_to_abbr, abbr_to_state, out_id_start)

        excel_cols_front = ["out_id","input_id","_in_address1","_in_address2","_in_address3","_in_city","_in_state","_in_pincode"]
        core_cols = ["Address","City","State","Pincode","Country",
                     "City_Confidence","State_Confidence","Overall_Confidence","Confidence_Level",
                     "Flag","Reason","Locality",
                     "_proposed_city_from_pin","_proposed_state_from_pin","_pincode_status"]
        excel_df = df_part[excel_cols_front + core_cols]
        fname=f"validated_output_part{i}.xlsx"
        excel_df.to_excel(fname,index=False)
        print(f"💾 Saved {fname}")

        db_df = df_part.copy().rename(columns={"Address":"address1"})
        drop_cols = ["_in_address1","_in_address2","_in_address3","_in_city","_in_state","_in_pincode",
                     "_proposed_city_from_pin","_proposed_state_from_pin","_pincode_status"]
        db_df = db_df.drop(columns=drop_cols).fillna("")

        with eng.begin() as con:
            for _,row in db_df.iterrows():
                con.execute(text("""
                    INSERT INTO av.validation_result_final
                    (out_id,input_id,address1,city,state,pincode,country,
                     city_confidence,state_confidence,overall_confidence,confidence_level,
                     flag,reason,locality)
                    VALUES(:oid,:iid,:a,:c,:s,:p,:co,:cc,:sc,:oc,:cl,:f,:r,:l)
                """), {
                    "oid": int(row["out_id"]),
                    "iid": None if row["input_id"]=="" else int(row["input_id"]) if str(row["input_id"]).isdigit() else None,
                    "a": row["address1"],
                    "c": row["City"],
                    "s": row["State"],
                    "p": row["Pincode"],
                    "co": row["Country"],
                    "cc": row["City_Confidence"],
                    "sc": row["State_Confidence"],
                    "oc": row["Overall_Confidence"],
                    "cl": row["Confidence_Level"],
                    "f": row["Flag"],
                    "r": row["Reason"],
                    "l": row["Locality"]
                })
        print(f"✅ Batch {i} inserted into DB ({len(db_df)} rows).")

    print("🎯 All batches processed successfully!")

if __name__=="__main__":
    main()
