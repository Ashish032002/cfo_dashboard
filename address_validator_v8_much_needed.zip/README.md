# Address Validator v8 (PostgreSQL)

- Batch size: 10,000 (Excel written + DB inserted per batch)
- No office-name scoring; locality extracted from input address only
- Primary keys: `id` on input table, `out_id` on output table
- Excel has input columns at the front for human QA (not inserted to DB)

## Run
1) python upload_input_data.py
2) python validator_final_v8.py
