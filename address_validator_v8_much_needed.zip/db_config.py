from sqlalchemy import create_engine

def get_db_connection():
    # TODO: set your actual connection values here
    user = "postgres"
    password = "admin@123"
    host = "localhost"
    port = "5432"
    database = "addressdb"
    schema = "av"

    engine = create_engine(
        f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{database}",
        connect_args={'options': f'-csearch_path={schema}'}
    )
    return engine
