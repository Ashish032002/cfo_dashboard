# Address Validator v17 (Dual-source best match)

Do **not** flag if input matches **any** of the two master sources.
Outputs both master_ref and pincode_ref matched city/state if available.
Batch size: 10,000. Excel per batch with original columns first.

## Run
1) python create_schema.py
2) python upload_master_data.py
3) python upload_pincode_master.py
4) python upload_input_data.py
5) python validator_final_v17.py
