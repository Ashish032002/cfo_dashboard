Address Validation - Final (Postgres, India)
--------------------------------------------

1️⃣ Create schema:
  psql -U postgres -d addressdb -f schema.sql

2️⃣ Load master data:
  python upload_abbreviation_list.py
  python upload_master_data.py

3️⃣ Load input addresses:
  python upload_input_data.py

4️⃣ Run validation:
  python validator_final.py

Outputs:
  - Table: av.validation_result
  - Excel: validated_output_final.xlsx

Logic (from flowchart):
  - Extract 6-digit pincode from any field.
  - If found in DB:
      - Single match => High confidence.
      - Multiple => Flag + possible addresses.
      - Not in DB => Flag as Foreign/Invalid.
  - If no pin, try City:
      - Found uniquely => Medium confidence.
      - Ambiguous / fuzzy => Flag.
  - If no city, try State:
      - Found => Low confidence.
      - Not found => Flag.
  - If nothing => Major conflict (Low confidence).

Confidence scale:
  High ≥0.85 | Medium 0.6–0.84 | Low <0.6

Columns in av.validation_result:
  input_id, norm_city, norm_state, extracted_pincode,
  matched_district, matched_state, matched_pincode,
  office_name, division_name, confidence_label,
  total_score, flag_reason, match_source, evidence
