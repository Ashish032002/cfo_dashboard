CREATE SCHEMA IF NOT EXISTS av;

CREATE TABLE IF NOT EXISTS av.country (
    country_id SERIAL PRIMARY KEY,
    country_name TEXT UNIQUE NOT NULL
);
INSERT INTO av.country (country_name) VALUES ('India') ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS av.state (
    state_id SERIAL PRIMARY KEY,
    state_name TEXT UNIQUE NOT NULL,
    country_id INT NOT NULL REFERENCES av.country(country_id)
);

CREATE TABLE IF NOT EXISTS av.district (
    district_id SERIAL PRIMARY KEY,
    district_name TEXT NOT NULL,
    state_id INT NOT NULL REFERENCES av.state(state_id),
    UNIQUE (district_name, state_id)
);

CREATE TABLE IF NOT EXISTS av.post_office (
    office_id BIGSERIAL PRIMARY KEY,
    office_name TEXT,
    division_name TEXT,
    district_id INT NOT NULL REFERENCES av.district(district_id),
    pincode CHAR(6) NOT NULL,
    office_type TEXT,
    delivery TEXT,
    latitude NUMERIC,
    longitude NUMERIC,
    UNIQUE (pincode, office_name, district_id)
);

CREATE TABLE IF NOT EXISTS av.state_abbreviation (
    id SERIAL PRIMARY KEY,
    state TEXT NOT NULL,
    state_abbreviation TEXT NOT NULL,
    UNIQUE (state),
    UNIQUE (state_abbreviation)
);

CREATE TABLE IF NOT EXISTS av.input_address (
    id BIGSERIAL PRIMARY KEY,
    name TEXT,
    address1 TEXT,
    address2 TEXT,
    address3 TEXT,
    city TEXT,
    state TEXT,
    country TEXT,
    pincode TEXT
);

CREATE TABLE IF NOT EXISTS av.validation_result (
    id BIGSERIAL PRIMARY KEY,
    input_id BIGINT REFERENCES av.input_address(id) ON DELETE CASCADE,
    norm_city TEXT,
    norm_state TEXT,
    extracted_pincode TEXT,
    matched_district TEXT,
    matched_state TEXT,
    matched_pincode TEXT,
    office_name TEXT,
    division_name TEXT,
    confidence_label TEXT,
    total_score NUMERIC,
    flag_reason TEXT,
    match_source TEXT,
    evidence JSONB,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_post_office_pin ON av.post_office(pincode);
CREATE INDEX IF NOT EXISTS idx_district_name ON av.district(district_name);
CREATE INDEX IF NOT EXISTS idx_state_name ON av.state(state_name);
