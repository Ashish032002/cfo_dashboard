import pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

# Expects 'abbreviation_list.csv' with columns ['State','Abbreviation']

def main():
    engine = get_db_connection()
    df = pd.read_csv("abbreviation_list.csv")
    df.columns = df.columns.str.strip().str.lower()
    if not {'state','abbreviation'} <= set(df.columns):
        raise ValueError("abbreviation_list.csv must have columns: State, Abbreviation")

    df = df[['state','abbreviation']].dropna().drop_duplicates()
    df['state'] = df['state'].str.strip().str.title()
    df['abbreviation'] = df['abbreviation'].str.strip().str.upper()

    with engine.begin() as con:
        for _, r in df.iterrows():
            con.execute(text("""                INSERT INTO av.state_abbreviation(state, state_abbreviation)
                VALUES (:s, :abbr)
                ON CONFLICT (state) DO UPDATE SET state_abbreviation=EXCLUDED.state_abbreviation
            """), {"s": r['state'], "abbr": r['abbreviation']})

    print("State abbreviation upload complete.")

if __name__ == "__main__":
    main()
