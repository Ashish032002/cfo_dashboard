import re, json, pandas as pd, numpy as np
from concurrent.futures import ProcessPoolExecutor
from sqlalchemy import text
from db_config import get_db_connection

try:
    from rapidfuzz import fuzz
    def match_score(a,b): return fuzz.token_set_ratio(a or '', b or '')/100
except:
    import difflib
    def match_score(a,b): return difflib.SequenceMatcher(None,(a or '').lower(),(b or '').lower()).ratio()

def clean_text(s):
    if pd.isna(s) or s is None: return None
    s = str(s)
    s = re.sub(r"[\.,;:/()_-]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s.title()

def extract_pin(*fields):
    txt = " ".join([str(x) for x in fields if x])
    m = re.search(r"(?<!\d)(\d{6})(?!\d)", txt)
    return m.group(1) if m else None

def label(score):
    if score>=0.85: return "High"
    elif score>=0.6: return "Medium"
    else: return "Low"

def process_chunk(df_chunk, po, state_abbr):
    results=[]
    pin_groups=po.groupby("pincode")
    for _,r in df_chunk.iterrows():
        rid=r.id
        a1,a2,a3=r.address1,r.address2,r.address3
        city,st,country,pin=r.city,r.state,r.country,r.pincode
        norm_city, norm_state = clean_text(city), clean_text(st)
        if norm_state and len(norm_state)<=3 and norm_state.upper() in state_abbr:
            norm_state=state_abbr[norm_state.upper()]
        extracted=extract_pin(a1,a2,a3,pin)
        flag=None; match_source=None
        matched_district=matched_state=matched_pin=office=division=None
        score=0
        # Step 1: pincode path
        if extracted:
            if extracted in pin_groups.groups:
                grp=pin_groups.get_group(extracted)
                if len(grp)>1:
                    flag="MULTIPLE_MATCH_PIN"; match_source="Pincode"; score=0.7
                else:
                    rec=grp.iloc[0]
                    matched_district,matched_state,matched_pin,office,division=rec.district_name,rec.state_name,rec.pincode,rec.office_name,rec.division_name
                    if norm_state and matched_state.lower()!=norm_state.lower():
                        flag="STATE_MISMATCH"
                    score=0.9; match_source="Pincode"
            else:
                flag="FOREIGN_OR_INVALID_PIN"; match_source="Pincode"; score=0.4
        else:
            # Step 2: city path
            if norm_city:
                cand=po[po['district_name'].str.lower()==norm_city.lower()]
                if not cand.empty:
                    matched_district=norm_city; matched_state=cand.iloc[0].state_name
                    score=0.75; match_source="City"
                else:
                    po['cscore']=po['district_name'].apply(lambda x: match_score(x,norm_city))
                    top=po.sort_values("cscore",ascending=False).head(1)
                    if top.iloc[0].cscore>=0.7:
                        rec=top.iloc[0]
                        matched_district,matched_state,matched_pin=rec.district_name,rec.state_name,rec.pincode
                        score=0.65; match_source="Fuzzy City"
                    else:
                        flag="CITY_NOT_FOUND"; score=0.4; match_source="City"
            elif norm_state:
                cand=po[po['state_name'].str.lower()==norm_state.lower()]
                if not cand.empty:
                    matched_state=norm_state; score=0.55; match_source="State"
                else:
                    flag="STATE_NOT_FOUND"; score=0.3; match_source="State"
            else:
                flag="NO_PIN_NO_CITY_NO_STATE"; score=0.2; match_source="None"

        conf=label(score)
        flag_reason=flag or ("OK" if conf=="High" else "CHECK")
        ev={"input":{"a1":a1,"a2":a2,"a3":a3,"city":city,"state":st,"pin":pin},
            "normalized":{"city":norm_city,"state":norm_state,"extracted_pin":extracted},
            "matched":{"district":matched_district,"state":matched_state,"pincode":matched_pin,"office":office,"division":division},
            "score":score,"label":conf,"source":match_source,"flag":flag_reason}
        results.append({"input_id":rid,"norm_city":norm_city,"norm_state":norm_state,"extracted_pincode":extracted,
                        "matched_district":matched_district,"matched_state":matched_state,"matched_pincode":matched_pin,
                        "office_name":office,"division_name":division,"confidence_label":conf,"total_score":score,
                        "flag_reason":flag_reason,"match_source":match_source,"evidence":json.dumps(ev,ensure_ascii=False)})
    return results

def main():
    eng=get_db_connection()
    with eng.begin() as con:
        po=pd.read_sql("SELECT po.office_name, po.division_name, po.pincode, d.district_name, s.state_name FROM av.post_office po JOIN av.district d ON po.district_id=d.district_id JOIN av.state s ON s.state_id=d.state_id",con)
        ab=pd.read_sql("SELECT state, state_abbreviation FROM av.state_abbreviation",con)
        inp=pd.read_sql("SELECT * FROM av.input_address ORDER BY id",con)

    state_abbr={r.state_abbreviation:r.state for _,r in ab.iterrows()}
    nprocs=8
    chunks=np.array_split(inp, nprocs)
    allres=[]
    with ProcessPoolExecutor(max_workers=nprocs) as ex:
        for res in ex.map(process_chunk, chunks, [po]*nprocs, [state_abbr]*nprocs):
            allres.extend(res)

    out=pd.DataFrame(allres)
    out.to_excel("validated_output_final.xlsx",index=False)
    with eng.begin() as con:
        con.execute(text("DELETE FROM av.validation_result"))
        for _,r in out.iterrows():
            con.execute(text("""INSERT INTO av.validation_result(input_id,norm_city,norm_state,extracted_pincode,matched_district,matched_state,matched_pincode,office_name,division_name,confidence_label,total_score,flag_reason,match_source,evidence) VALUES(:input_id,:norm_city,:norm_state,:extracted_pincode,:matched_district,:matched_state,:matched_pincode,:office_name,:division_name,:confidence_label,:total_score,:flag_reason,:match_source,CAST(:evidence AS JSONB))"""),r.to_dict())
    print(f"Validation complete using {nprocs} processes. Rows: {len(out)}")

if __name__=="__main__": main()
