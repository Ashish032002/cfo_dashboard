import pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

# Expects 'master_data.csv' with columns:
# ['circlename','regionname','divisionname','officename','pincode','officetype',
#  'delivery','district','statename','latitude','longitude']

def main():
    engine = get_db_connection()
    df = pd.read_csv("master_data.csv")
    df.columns = df.columns.str.strip().str.lower()

    required = ['divisionname','officename','pincode','officetype','delivery','district','statename','latitude','longitude']
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns in master_data.csv: {missing}")

    def clean(x):
        return None if pd.isna(x) else str(x).strip()

    df['divisionname'] = df['divisionname'].map(clean)
    df['officename'] = df['officename'].map(clean)
    df['district'] = df['district'].map(clean)
    df['statename'] = df['statename'].map(lambda s: clean(s).title() if s else None)
    df['pincode'] = df['pincode'].astype(str).str.extract(r"(\d{6})", expand=False)
    df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
    df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')

    with engine.begin() as con:
        cid = con.execute(text("SELECT country_id FROM av.country WHERE country_name='India'")).scalar()

        states = pd.DataFrame(sorted(df['statename'].dropna().unique()), columns=['state_name'])
        states['country_id'] = cid
        for _, r in states.iterrows():
            con.execute(text("""                INSERT INTO av.state(state_name, country_id)
                VALUES (:s, :cid)
                ON CONFLICT (state_name) DO NOTHING
            """), {"s": r['state_name'], "cid": r['country_id']})

        stmap = dict(con.execute(text("SELECT state_name, state_id FROM av.state")).all())

        dists = (df[['district','statename']].dropna().drop_duplicates()
                 .rename(columns={'district':'district_name','statename':'state_name'}))
        for _, r in dists.iterrows():
            sid = stmap.get(r['state_name'])
            con.execute(text("""                INSERT INTO av.district(district_name, state_id)
                VALUES (:d, :sid)
                ON CONFLICT (district_name, state_id) DO NOTHING
            """), {"d": r['district_name'], "sid": sid})

        dist_rows = con.execute(text("""            SELECT d.district_id, d.district_name, s.state_name, s.state_id
            FROM av.district d JOIN av.state s ON s.state_id=d.state_id
        """))

        dist_lookup = {}
        for r in dist_rows:
            dist_lookup[(r.district_name, r.state_name)] = r.district_id

        po = df[['officename','divisionname','district','statename','pincode','officetype','delivery','latitude','longitude']].dropna(subset=['district','statename','pincode'])
        po = po.rename(columns={'officename':'office_name','divisionname':'division_name','officetype':'office_type'})
        inserted = 0
        for _, r in po.iterrows():
            key = (r['district'], r['statename'])
            did = dist_lookup.get(key)
            if not did:
                continue
            con.execute(text("""                INSERT INTO av.post_office(office_name, division_name, district_id, pincode, office_type, delivery, latitude, longitude)
                VALUES (:o, :div, :did, :pin, :t, :del, :lat, :lon)
                ON CONFLICT (pincode, office_name, district_id) DO NOTHING
            """), {
                "o": r['office_name'], "div": r['division_name'], "did": did,
                "pin": r['pincode'], "t": r['office_type'], "del": r['delivery'],
                "lat": r['latitude'], "lon": r['longitude']
            })
            inserted += 1

    print("Master data upload complete.")

if __name__ == "__main__":
    main()
