import pandas as pd
from db_config import get_db_connection
from sqlalchemy import text

# Expects 'Input_address_2.xlsx' with columns including (case-insensitive)
# Address1, Address2, Address3, City, State, Country, Pincode, Name

def main():
    engine = get_db_connection()
    df = pd.read_excel("Input_address_2.xlsx")
    df.columns = df.columns.str.strip().str.lower()

    col_map = {
        'address1':'address1','address2':'address2','address3':'address3',
        'city':'city','state':'state','country':'country','pincode':'pincode',
        'name':'name'
    }
    present = {k:v for k,v in col_map.items() if k in df.columns}
    df = df[list(present.keys())].rename(columns=present)

    for c in ['name','address1','address2','address3','city','state','country','pincode']:
        if c not in df.columns:
            df[c] = None
        df[c] = df[c].astype(str).str.strip().replace({'nan':None})

    with engine.begin() as con:
        for _, r in df.iterrows():
            con.execute(text("""                INSERT INTO av.input_address(name, address1, address2, address3, city, state, country, pincode)
                VALUES (:name, :a1, :a2, :a3, :city, :state, :country, :pin)
            """), dict(name=r['name'], a1=r['address1'], a2=r['address2'], a3=r['address3'],
                       city=r['city'], state=r['state'], country=r['country'], pin=r['pincode']))
    print(f"Uploaded {len(df)} input addresses.")

if __name__ == "__main__":
    main()
