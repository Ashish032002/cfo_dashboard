
import os, re, json, unicodedata
import pandas as pd
from sqlalchemy import text
from tqdm import tqdm
from db_config import get_db_connection

try:
    from rapidfuzz import fuzz, process
    def sim(a,b): return fuzz.token_set_ratio(a or "", b or "")/100
except:
    import difflib
    def sim(a,b): return difflib.SequenceMatcher(None,(a or "").lower(),(b or "").lower()).ratio()

BATCH_SIZE = 10000
STOP_WORDS={"division","city","district","region","circle","zone","south","north","east","west","office","so","s.o","bo","b.o","po","p.o","head","branch","rms","ho","do","co","post","nodal","sub","urban","rural","taluk","mandal","gate","road","rd","street","st","lane","ln"}
CITY_ALIASES={"bombay":"mumbai","bengaluru":"bangalore","bengluru":"bangalore","benglore":"bangalore","calcutta":"kolkata","trivandrum":"thiruvananthapuram","kochi":"cochin","cochin":"kochi","vadodara":"baroda","baroda":"vadodara","pondicherry":"puducherry","nasik":"nashik","gurgaon":"gurugram","gurugram":"gurgaon","ahmadabad":"ahmedabad"}

def strip_accents(s): return "".join(ch for ch in unicodedata.normalize("NFKD", str(s)) if not unicodedata.combining(ch))
def clean_text(s):
    s=str(s or "")
    s=strip_accents(s).lower()
    s=re.sub(r"[^\w\s]"," ",s)
    s=re.sub(r"\s+"," ",s).strip()
    return s
def normalize_city(s):
    s=clean_text(s)
    toks=[CITY_ALIASES.get(t,t) for t in s.split() if t not in STOP_WORDS and not t.isdigit()]
    return " ".join(toks).strip().title()

def load_state_mappings():
    here=os.path.dirname(__file__)
    csvp=os.path.join(here,"datasets","abbreviation_list 1.csv")
    df=pd.read_csv(csvp)
    df.columns=df.columns.str.strip().str.title()
    df["State"]=df["State"].astype(str).str.strip().str.title()
    df["Abbreviation"]=df["Abbreviation"].astype(str).str.strip().str.upper()
    s2a=dict(zip(df["State"],df["Abbreviation"]))
    a2s=dict(zip(df["Abbreviation"],df["State"]))
    return s2a,a2s

def normalize_state(s, s2a, a2s):
    if not s: return None
    sc=clean_text(s).replace(".","").upper().strip()
    if sc in a2s: return a2s[sc]
    for full,abbr in s2a.items():
        if clean_text(full).upper()==sc:
            return full
    try:
        from rapidfuzz import process
        cand=process.extractOne(sc.title(), list(s2a.keys()))
        if cand and cand[1] >= 85:
            return cand[0]
    except: pass
    return sc.title()

def norm_pin(s):
    if not s: return None
    m = re.search(r"(\d{6})", str(s))
    return m.group(1) if m else None

def extract_pin_from_text(txt):
    if not txt: return None
    return norm_pin(txt)

def extract_locality(addr, city, state, pin):
    s=clean_text(addr)
    for token in [clean_text(city or ""), clean_text(state or ""), str(pin or "")]:
        if token: s=s.replace(token," ")
    toks=[t for t in s.split() if t not in STOP_WORDS and not t.isdigit()]
    return " ".join(toks[:6]).title() if toks else None

def build_indexes(master, s2a, a2s):
    m=master.copy()
    m["pincode"]=m["pincode"].apply(norm_pin)
    m=m.dropna(subset=["pincode"])
    m["city_norm"]=m["city"].apply(normalize_city)
    m["state_norm"]=m["state"].apply(lambda x: normalize_state(x,s2a,a2s))
    by_pin  ={k:v.copy() for k,v in m.groupby("pincode")}
    by_city ={k:v.copy() for k,v in m.groupby("city_norm")}
    by_state={k:v.copy() for k,v in m.groupby("state_norm")}
    return by_pin,by_city,by_state

def pick_best_from_df(dfc, city_in, state_in):
    df=dfc.copy()
    df["city_sim"]=df["city_norm"].apply(lambda x: sim(x,city_in))
    df["state_sim"]=df["state_norm"].apply(lambda x: sim(x,state_in))
    df["score"]=0.6*df["city_sim"]+0.4*df["state_sim"]
    best=df.sort_values("score", ascending=False).iloc[0]
    return best, df

def classify_ambiguity(city_in_raw, state_in_raw, best_city, best_state, s2a, a2s, candidates):
    types=[]
    state_in_full = normalize_state(state_in_raw, s2a, a2s)
    best_state_full = normalize_state(best_state, s2a, a2s)
    if city_in_raw and best_city and normalize_city(city_in_raw)!=normalize_city(best_city):
        types.append("CityMismatch")
    if state_in_full and best_state_full and clean_text(state_in_full).title()!=clean_text(best_state_full).title():
        types.append("StateMismatch")
    if not types:
        cn = len(set(candidates["city_norm"])) if "city_norm" in candidates else 0
        sn = len(set(candidates["state_norm"])) if "state_norm" in candidates else 0
        if cn>1 and sn>1: types.append("multi-city-state")
        elif cn>1: types.append("multi-city")
        elif sn>1: types.append("multi-state")
        else: types.append("none")
    return "+".join(types)

def run_batch(df, by_pin, by_city, by_state, s2a, a2s, start_out_id):
    results=[]; out_id=start_out_id
    for _,r in tqdm(df.iterrows(), total=len(df), desc="Validating"):
        input_id=int(r["id"])
        a1,a2,a3=r.get("address1"),r.get("address2"),r.get("address3")
        addr_raw=" ".join([str(x) for x in [a1,a2,a3] if x and str(x).lower()!="nan"]).strip()
        addr_pin=extract_pin_from_text(addr_raw)
        pin = addr_pin or norm_pin(r.get("pincode"))

        city_in_raw = r.get("city")
        state_in_raw = r.get("state")

        city_in=normalize_city(city_in_raw)
        state_in=normalize_state(state_in_raw,s2a,a2s)

        best_city=city_in; best_state=state_in
        flag="No"; reason=""; ambiguity_type="none"; possible=[]
        city_conf=0.0; state_conf=0.0

        if pin and re.fullmatch(r"\d{6}", pin):
            dfp=by_pin.get(pin)
            if dfp is None or dfp.empty:
                # Rescue: rebuild key set once (prevent false negatives due to dtype)
                if pin in list(by_pin.keys()):
                    dfp = by_pin[pin]
            if dfp is None or dfp.empty:
                flag="Yes"; reason="Pincode present but not found in master_ref after normalization"; ambiguity_type="InvalidPincode"
            else:
                best, scored = pick_best_from_df(dfp, city_in, state_in)
                best_city=str(best["city"])
                best_state=normalize_state(str(best["state"]), s2a, a2s)
                city_conf=sim(best["city_norm"], city_in)
                state_conf=sim(best["state_norm"], state_in)
                ambiguity_type=classify_ambiguity(city_in_raw, state_in_raw, best_city, best_state, s2a, a2s, scored)
                if "Mismatch" in ambiguity_type or "multi" in ambiguity_type:
                    flag="Yes"; reason=reason or "City/State mismatch with pincode-derived master"
                    top3=scored.sort_values("score",ascending=False).head(3)[["city","state","pincode","score"]]
                    for _,rw in top3.iterrows():
                        possible.append({
                            "input_city": str(city_in_raw),
                            "master_city": str(rw["city"]),
                            "input_state": normalize_state(str(state_in_raw), s2a, a2s),
                            "master_state": normalize_state(str(rw["state"]), s2a, a2s),
                            "pincode": str(rw["pincode"]),
                            "score": float(rw["score"])
                        })
        else:
            if not pin: reason="NoPincodeInInput"; ambiguity_type="NoPincode"
            else: reason="InvalidPincodeFormat"; ambiguity_type="InvalidPincode"
            if city_in and city_in in by_city:
                dfc=by_city[city_in]
                best, scored = pick_best_from_df(dfc, city_in, state_in)
                best_city=str(best["city"]); best_state=normalize_state(str(best["state"]),s2a,a2s)
                city_conf=sim(best["city_norm"], city_in); state_conf=sim(best["state_norm"], state_in)
                if len(set(scored["state_norm"]))>1:
                    flag="Yes"; ambiguity_type="multi-state"
                    top=scored.sort_values("score",ascending=False).drop_duplicates(["state_norm"]).head(3)
                    for _,rw in top.iterrows():
                        possible.append({
                            "input_city": str(city_in_raw),
                            "master_city": str(rw["city"]),
                            "input_state": normalize_state(str(state_in_raw), s2a, a2s),
                            "master_state": normalize_state(str(rw["state"]), s2a, a2s),
                            "pincode": str(rw["pincode"]),
                            "score": float(rw["score"])
                        })
            elif state_in and state_in in by_state:
                dfs=by_state[state_in]
                freq=dfs["city_norm"].value_counts()
                if not freq.empty:
                    top_city=freq.index[0]
                    row=dfs[dfs["city_norm"]==top_city].iloc[0]
                    best_city=str(row["city"]); best_state=normalize_state(str(row["state"]),s2a,a2s)
                    city_conf=sim(top_city, city_in); state_conf=1.0
                    if len(freq)>1:
                        flag="Yes"; ambiguity_type="multi-city"
                        for cn,_ in freq.head(3).items():
                            r2=dfs[dfs["city_norm"]==cn].iloc[0]
                            possible.append({
                                "input_city": str(city_in_raw),
                                "master_city": str(r2["city"]),
                                "input_state": normalize_state(str(state_in_raw), s2a, a2s),
                                "master_state": normalize_state(str(r2["state"]), s2a, a2s),
                                "pincode": str(r2["pincode"]),
                                "score": float(sim(cn,city_in))
                            })
                else:
                    flag="Yes"; reason=reason or "Cannot derive city/state"
            else:
                flag="Yes"; reason=reason or "Cannot derive city/state"

        overall=0.6*city_conf+0.4*state_conf
        level="High" if overall>=0.8 else ("Medium" if overall>=0.6 else "Low")
        locality=extract_locality(addr_raw, best_city, best_state, pin)

        results.append({
            "out_id": out_id, "input_id": input_id,
            "_in_address1": a1, "_in_address2": a2, "_in_address3": a3,
            "_in_city": city_in_raw, "_in_state": state_in_raw, "_in_pincode": r.get("pincode"),
            "address1": addr_raw, "city": best_city, "state": best_state, "pincode": pin, "country": "India",
            "city_confidence": round(float(city_conf),3), "state_confidence": round(float(state_conf),3),
            "overall_confidence": round(float(overall),3), "confidence_level": level,
            "flag": flag, "reason": reason, "locality": locality, "ambiguity_type": ambiguity_type,
            "possible_addresses": results  # placeholder; replaced next line
        })
        results[-1]["possible_addresses"] = possible
        out_id+=1
    return results, out_id

def main():
    print("Starting Address Validator v13 ...")
    eng=get_db_connection()
    s2a,a2s=load_state_mappings()
    with eng.begin() as con:
        master=pd.read_sql("SELECT city,state,pincode,office_name FROM av.master_ref", con)
        inp=pd.read_sql("SELECT * FROM av.input_addresses ORDER BY id", con)
    by_pin,by_city,by_state=build_indexes(master,s2a,a2s)
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.validation_result_final RESTART IDENTITY CASCADE"))

    start=1; total=len(inp)
    for bno,i in enumerate(range(0,total,BATCH_SIZE), start=1):
        chunk=inp.iloc[i:i+BATCH_SIZE].copy()
        results,start=run_batch(chunk,by_pin,by_city,by_state,s2a,a2s,start)
        df=pd.DataFrame(results)
        cols_front=["out_id","input_id","_in_address1","_in_address2","_in_address3","_in_city","_in_state","_in_pincode"]
        rest=[c for c in df.columns if c not in cols_front]
        df=df[cols_front+rest]
        xname=f"validated_output_part{bno}.xlsx"
        df.to_excel(os.path.join(os.path.dirname(__file__), xname), index=False)
        print(f"Saved {xname}")
        # DB insert
        df_db=df.drop(columns=[c for c in cols_front if c.startswith('_')], errors='ignore').copy()
        with eng.begin() as con:
            for _,row in df_db.iterrows():
                pa=row.get("possible_addresses",[])
                pa_json=json.dumps(pa if isinstance(pa,(list,dict)) else [])
                con.execute(text("""
                    INSERT INTO av.validation_result_final(
                        out_id,input_id,address1,city,state,pincode,country,
                        city_confidence,state_confidence,overall_confidence,confidence_level,
                        flag,reason,locality,ambiguity_type,possible_addresses
                    ) VALUES(
                        :oid,:iid,:a,:c,:s,:p,:co,:cc,:sc,:oc,:cl,:f,:r,:l,:at,:pa::jsonb
                    )
                """),{
                    "oid":int(row["out_id"]),"iid":int(row["input_id"]),
                    "a":row["address1"],"c":row["city"],"s":row["state"],"p":row["pincode"],
                    "co":row.get("country","India"),"cc":row.get("city_confidence",0.0),
                    "sc":row.get("state_confidence",0.0),"oc":row.get("overall_confidence",0.0),
                    "cl":row.get("confidence_level","Low"),"f":row.get("flag","No"),
                    "r":row.get("reason",""),"l":row.get("locality"),
                    "at":row.get("ambiguity_type","none"),"pa":pa_json
                })
        print(f"Batch {bno}: inserted {len(df_db)} rows into DB.")
    print("Done.")

if __name__=="__main__":
    main()
