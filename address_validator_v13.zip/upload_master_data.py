
import os, pandas as pd, re
from sqlalchemy import text
from db_config import get_db_connection

def norm_pin(s):
    if pd.isna(s): return None
    s = str(s).strip()
    m = re.search(r'(\d{6})', s)
    return m.group(1) if m else None

def main():
    eng = get_db_connection()
    src = None
    for c in ["pincode_master.xlsx", "master_data.xlsx", "master_data.csv"]:
        p = os.path.join(os.path.dirname(__file__), c)
        if os.path.exists(p): src = p; break
    if not src:
        raise FileNotFoundError("Place pincode_master.xlsx / master_data.xlsx / master_data.csv next to this script.")
    df = pd.read_excel(src) if src.endswith(".xlsx") else pd.read_csv(src)
    cols = {c.lower().strip(): c for c in df.columns}
    def pick(*names):
        for n in names:
            if n in cols: return cols[n]
        return None
    city_col   = pick("divisionname","city","division","officename","office_name","office")
    state_col  = pick("statename","state")
    pin_col    = pick("pincode","pin code","pin","pincode6")
    office_col = pick("office_name","officename","office")
    if not (city_col and state_col and pin_col):
        raise ValueError(f"Could not detect core columns. Found: {list(df.columns)}")
    m = pd.DataFrame({
        "city": df[city_col].astype(str).str.strip().str.title(),
        "state": df[state_col].astype(str).str.strip().str.title(),
        "pincode": df[pin_col].apply(norm_pin),
        "office_name": (df[office_col] if office_col else "").astype(str).str.strip().str.title()
    })
    m = m.dropna(subset=["pincode"]).drop_duplicates(subset=["pincode","city","state"], keep="first")
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.master_ref RESTART IDENTITY CASCADE"))
        m.to_sql("master_ref", con, schema="av", if_exists="append", index=False)
    print(f"Loaded {len(m):,} rows into av.master_ref from {os.path.basename(src)}")

if __name__ == "__main__":
    main()
