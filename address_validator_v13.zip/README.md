
# Address Validator v13

- Strong pincode normalization on both master & inputs to avoid false 'not found'
- Possible addresses include **both input and master** city/state for mismatches
- State abbreviations normalized to **full names** before comparisons and output
- 10k batch Excel & per-batch DB insert
- Locality only from input address

Run:
1) python create_schema.py
2) python upload_master_data.py
3) python upload_input_data.py
4) python validator_final_v13.py
