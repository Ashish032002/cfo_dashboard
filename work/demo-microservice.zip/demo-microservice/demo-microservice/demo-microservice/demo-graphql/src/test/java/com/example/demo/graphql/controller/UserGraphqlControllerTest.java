package com.example.demo.graphql.controller;

import com.example.demo.graphql.model.User;
import com.example.demo.graphql.resolver.GraphqlExceptionResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.graphql.GraphQlTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.graphql.test.tester.GraphQlTester;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;

@GraphQlTest(UserGraphqlController.class)
public class UserGraphqlControllerTest {

    @Autowired
    private GraphQlTester graphQlTester;

    @Autowired
    private WebClient restApiClient;

    @Autowired
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Autowired
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Autowired
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Autowired
    private WebClient.ResponseSpec responseSpec;

    @BeforeEach
    void setup() {
        // GET and DELETE return RequestHeadersUriSpec (for requests without body)
        Mockito.when(restApiClient.get()).thenReturn(requestHeadersUriSpec);
        Mockito.when(restApiClient.delete()).thenReturn(requestHeadersUriSpec);

        // uri(...) for GET/DELETE returns RequestHeadersUriSpec again (chainable)
        Mockito.when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersUriSpec);
        Mockito.when(requestHeadersUriSpec.uri(anyString(), Optional.ofNullable(any()))).thenReturn(requestHeadersUriSpec);

        // retrieve() returns ResponseSpec
        Mockito.when(requestHeadersUriSpec.retrieve()).thenReturn(responseSpec);

        // POST and PUT return RequestBodyUriSpec (for requests with body)
        Mockito.when(restApiClient.post()).thenReturn(requestBodyUriSpec);
        Mockito.when(restApiClient.put()).thenReturn(requestBodyUriSpec);

        // uri(...) for POST/PUT returns RequestBodyUriSpec again (chainable)
        Mockito.when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(anyString(), Optional.ofNullable(any()))).thenReturn(requestBodyUriSpec);

        // bodyValue(...) returns RequestHeadersSpec
        Mockito.when(requestBodyUriSpec.bodyValue(any())).thenReturn(requestHeadersSpec);

        // retrieve() from headers spec returns ResponseSpec
        Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
    }

    @Test
    void testUsersQuery() {
        User user = new User(1L, "John", "john@example.com");
        Mockito.when(responseSpec.bodyToFlux(User.class)).thenReturn(Flux.just(user));

        String query = """
            query {
                users {
                    id
                    name
                    email
                }
            }
        """;

        graphQlTester.document(query)
                .execute()
                .path("users[0].name").entity(String.class).isEqualTo("John");
    }

    @Test
    void testUserByIdQuery() {
        User user = new User(2L, "Alice", "alice@example.com");
        Mockito.when(responseSpec.bodyToMono(User.class)).thenReturn(Mono.just(user));

        String query = """
            query {
                userById(id: 2) {
                    id
                    name
                    email
                }
            }
        """;

        graphQlTester.document(query)
                .execute()
                .path("userById.name").entity(String.class).isEqualTo("Alice");
    }

    @Test
    void testCreateUserMutation() {
        User createdUser = new User(3L, "Bob", "bob@example.com");
        Mockito.when(responseSpec.bodyToMono(User.class)).thenReturn(Mono.just(createdUser));

        String mutation = """
            mutation {
                createUser(input: { name: "Bob", email: "bob@example.com" }) {
                    id
                    name
                    email
                }
            }
        """;

        graphQlTester.document(mutation)
                .execute()
                .path("createUser.name").entity(String.class).isEqualTo("Bob");
    }

    @Test
    void testUpdateUserMutation() {
        User updatedUser = new User(4L, "Charlie", "charlie@example.com");
        Mockito.when(responseSpec.bodyToMono(User.class)).thenReturn(Mono.just(updatedUser));

        String mutation = """
            mutation {
                updateUser(id: 4, input: { name: "Charlie", email: "charlie@example.com" }) {
                    id
                    name
                    email
                }
            }
        """;

        graphQlTester.document(mutation)
                .execute()
                .path("updateUser.name").entity(String.class).isEqualTo("Charlie");
    }

    @Test
    void testDeleteUserMutation() {
        Mockito.when(responseSpec.bodyToMono(Void.class)).thenReturn(Mono.empty());

        String mutation = """
            mutation {
                deleteUser(id: 5)
            }
        """;

        graphQlTester.document(mutation)
                .execute()
                .path("deleteUser").entity(Boolean.class).isEqualTo(true);
    }

    @TestConfiguration
    static class WebClientTestConfig {
        @Bean
        public WebClient restApiClient() {
            return Mockito.mock(WebClient.class);
        }

        @Bean
        public WebClient.RequestHeadersUriSpec<?> requestHeadersUriSpec() {
            return Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        }

        @Bean
        public WebClient.RequestHeadersSpec<?> requestHeadersSpec() {
            return Mockito.mock(WebClient.RequestHeadersSpec.class);
        }

        @Bean
        public WebClient.RequestBodyUriSpec requestBodyUriSpec() {
            return Mockito.mock(WebClient.RequestBodyUriSpec.class);
        }

        @Bean
        public WebClient.ResponseSpec responseSpec() {
            return Mockito.mock(WebClient.ResponseSpec.class);
        }
    }
}