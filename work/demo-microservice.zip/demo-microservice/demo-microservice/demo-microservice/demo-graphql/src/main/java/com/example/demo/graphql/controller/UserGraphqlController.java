package com.example.demo.graphql.controller;

import com.example.demo.graphql.model.CreateUserInput;
import com.example.demo.graphql.model.User;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Controller
public class UserGraphqlController {

    private final WebClient restApiClient;
    public UserGraphqlController(WebClient restApiClient) {
        this.restApiClient = restApiClient;
    }

    @QueryMapping
    public Flux<User> users() {
        return restApiClient.get()
                .uri("/users")
                .retrieve()
                .bodyToFlux(User.class);
    }

    @QueryMapping
    public Mono<User> userById(@Argument Long id) {
        return restApiClient.get()
                .uri("/users/{id}", id)
                .retrieve()
                .bodyToMono(User.class);
    }

    @MutationMapping
    public Mono<User> createUser(@Argument CreateUserInput input) {
        return restApiClient.post()
                .uri("/users")
                .bodyValue(input)
                .retrieve()
                .bodyToMono(User.class);
    }

    @MutationMapping
    public Mono<User> updateUser(@Argument Long id, @Argument CreateUserInput input) {
        return restApiClient.put()
                .uri("/users/{id}", id)
                .bodyValue(input)
                .retrieve()
                .bodyToMono(User.class);
    }

    @MutationMapping
    public Mono<Boolean> deleteUser(@Argument Long id) {
        return restApiClient.delete()
                .uri("/users/{id}", id)
                .retrieve()
                .bodyToMono(Void.class)
                .thenReturn(true);
    }
}
