package com.example.demo.graphql.resolver;

import org.springframework.stereotype.Component;
import org.springframework.graphql.execution.DataFetcherExceptionResolverAdapter;
import graphql.GraphqlErrorBuilder;
import graphql.GraphQLError;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.graphql.execution.ErrorType;

@Component
public class GraphqlExceptionResolver extends DataFetcherExceptionResolverAdapter {

    @Override
    protected GraphQLError resolveToSingleError(Throwable ex, DataFetchingEnvironment env) {
        if (ex instanceof WebClientResponseException wcre) {
            String message = switch (wcre.getStatusCode().value()) {
                case 404 -> "User not found";
                case 409 -> "Duplicate email";
                case 400 -> "Invalid request: " + wcre.getResponseBodyAsString();
                default  -> "Upstream REST error: " + wcre.getMessage();
            };

            ErrorType errorType = switch (wcre.getStatusCode().value()) {
                case 404 -> ErrorType.NOT_FOUND;
                case 409, 400 -> ErrorType.BAD_REQUEST;
                default -> ErrorType.INTERNAL_ERROR;
            };

            return GraphqlErrorBuilder.newError(env)
                    .message(message)
                    .errorType(errorType)
                    .build();
        }

        if (ex instanceof MethodArgumentNotValidException manve) {
            return GraphqlErrorBuilder.newError(env)
                    .message("Validation failed: " + manve.getMessage())
                    .errorType(ErrorType.BAD_REQUEST)
                    .build();
        }

        if (ex instanceof WebClientException) {
            return GraphqlErrorBuilder.newError(env)
                    .message("Service unavailable: " + ex.getMessage())
                    .errorType(ErrorType.INTERNAL_ERROR)
                    .build();
        }

        return GraphqlErrorBuilder.newError(env)
                .message("Unexpected error: " + ex.getMessage())
                .errorType(ErrorType.INTERNAL_ERROR)
                .build();
    }
}
