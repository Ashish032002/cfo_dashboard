package com.example.demo.service;

import com.example.demo.dto.User;
import com.example.demo.functional.Transformer;
import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepository;

    private final Transformer<UserEntity, User> entityToDto = ue -> new User(
            ue.getId(),
            ue.getName(),
            ue.getEmail()
    );

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Flux<User> getAllUsers() {
        return userRepository.findAll()
                .map(entityToDto::transform);
    }

    public Mono<User> getUserById(Long id) {
        return userRepository.findById(id)
                .map(entityToDto::transform);
    }

    public Mono<User> createUser(Mono<User> userMono) {
        return userMono
                .map(user -> {
                    UserEntity entity = new UserEntity();
                    entity.setId(user.getId());
                    entity.setName(user.getName());
                    entity.setEmail(user.getEmail());
                    return entity;
                })
                .flatMap(userRepository::save)
                .map(entityToDto::transform);
    }

    public Mono<Void> deleteUser(Long id) {
        return userRepository.deleteById(id);
    }

    // Example: Using Java Streams internally
    public Mono<List<String>> getAllUserEmailsUpperCase() {
        return userRepository.findAll()
                .map(UserEntity::getEmail)
                .collectList()
                .map(emails -> emails.stream()
                        .map(String::toUpperCase)
                        .collect(Collectors.toList())
                );
    }
}
