/*
package com.example.demo.service;




import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;


public class UserServiceTest {

    private UserRepository userRepository;
    private UserService userService;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class); // Mocked repository
        userService = new UserService(userRepository);
    }

    @Nested
    @DisplayName("Unit Tests")
    class UnitTests {

        @Test
        @DisplayName("Should create user successfully")
        void testCreateUser() {
            User user = new User(1L, "Alice", "alice@example.com");

            when(UserRepository.save(user)).thenReturn(user);

            User created = userService.createUser(user);

            assertEquals("Alice", created.getName());
            assertEquals("alice@example.com", created.getEmail());
            verify(userRepository, times(1)).save(user);
        }

        @Test
        @DisplayName("Should return user by ID")
        void testGetUserById() {
            User user = new User(2L, "Bob", "bob@example.com");

            when(userRepository.findById(2L)).thenReturn(Optional.of(user));

            User result = userService.getUserById(2L);

            assertNotNull(result);
            assertEquals("Bob", result.getName());
            verify(userRepository, times(1)).findById(2L);
        }

        @Test
        @DisplayName("Should update user details")
        void testUpdateUser() {
            User existing = new User(3L, "Charlie", "charlie@old.com");
            User updated = new User(3L, "Charlie", "charlie@new.com");

            when(userRepository.findById(3L)).thenReturn(Optional.of(existing));
            when(userRepository.save(updated)).thenReturn(updated);

            User result = userService.updateUser(3L, updated);

            assertEquals("charlie@new.com", result.getEmail());
            verify(userRepository).save(updated);
        }

        @Test
        @DisplayName("Should delete user")
        void testDeleteUser() {
            Long userId = 4L;

            doNothing().when(userRepository).deleteById(userId);

            userService.deleteUser(userId);

            verify(userRepository, times(1)).deleteById(userId);
        }
    }

    @Nested
    @DisplayName("Functional Tests")
    class FunctionalTests {

        @Test
        @DisplayName("Full CRUD lifecycle")
        void testUserCrudLifecycle() {
            User user = new User(5L, "Daisy", "daisy@example.com");

            // Create
            when(userRepository.save(user)).thenReturn(user);
            User created = userService.createUser(user);
            assertEquals("Daisy", created.getName());

            // Read
            when(userRepository.findById(5L)).thenReturn(Optional.of(user));
            User fetched = userService.getUserById(5L);
            assertEquals("daisy@example.com", fetched.getEmail());

            // Update
            User updated = new User(5L, "Daisy", "daisy@newmail.com");
            when(userRepository.save(updated)).thenReturn(updated);
            User result = userService.updateUser(5L, updated);
            assertEquals("daisy@newmail.com", result.getEmail());

            // Delete
            doNothing().when(userRepository).deleteById(5L);
            userService.deleteUser(5L);
            verify(userRepository).deleteById(5L);
        }
    }
}
*/