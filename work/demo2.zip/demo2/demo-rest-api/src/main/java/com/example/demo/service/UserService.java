package com.example.demo.service;

import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserRepository;
import com.example.demo.dto.User;
import com.example.demo.functional.Transformer;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class UserService {

    private final UserRepository userRepository;

    // Mapper: Entity -> DTO
    private final Transformer<UserEntity, User> entityToDto = ue ->
            new User(ue.getId(), ue.getName(), ue.getEmail());

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Get all users
    public Flux<User> getAllUsers() {
        return userRepository.findAll()
                .map(entityToDto::transform);
    }

    // Get user by ID
    public Mono<User> getUserById(Long id) {
        return userRepository.findById(id)
                .map(entityToDto::transform);
    }

    // Create a new user (id is auto-generated)
    public Mono<User> createUser(Mono<User> userMono) {
        return userMono
                .map(user -> {
                    UserEntity entity = new UserEntity();

                    entity.setName(user.getName());
                    entity.setEmail(user.getEmail());
                    return entity;
                })
                .flatMap(userRepository::save)
                .map(entityToDto::transform);
    }

    // Update existing user
    public Mono<User> updateUser(Long id, Mono<User> userMono) {
        return userRepository.findById(id)
                .flatMap(existingEntity ->
                        userMono.map(u -> {
                            existingEntity.setName(u.getName());
                            existingEntity.setEmail(u.getEmail());
                            return existingEntity;
                        })
                )
                .flatMap(userRepository::save)
                .map(entityToDto::transform);
    }

    // Delete user by ID
    public Mono<Void> deleteUser(Long id) {
        return userRepository.deleteById(id);
    }
}