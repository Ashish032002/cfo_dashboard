# Address Validator v18 (Windows-friendly)

**Version:** v18  
**Goal:** Validate and correct Indian address records using two master datasets: `master_data.csv` and `pincode_master.csv`. If an input matches **either** master dataset, it is **not flagged**. We always return authoritative `city` and `state` (if available) and clear flag reasons when matched.

## What’s new in v18
- Deterministic parsing: no “possible addresses” explosion. We **do not** generate combinatoric variants.
- Robust normalization for `city`, `state`, `pincode` (trims, uppercases, collapses spaces, removes punctuation, fixes common aliases).
- Strict rule: **If input matches in `master_data` OR `pincode_master`, do _not_ flag**. We surface `match_source` and authoritative fields.
- Clean flag taxonomy (multiple flags allowed): `MISSING_FIELDS`, `INVALID_PINCODE_FORMAT`, `NOT_IN_MASTER`, `PINCODE_NOT_FOUND`, `CONFLICT_CITY_STATE`, `MULTI_STATE_IN_ADDRESS`, `MULTI_CITY_IN_ADDRESS`.
- Confidence score in [0,1] with simple, explainable rubric.
- Windows-first: tested path handling; no shell-only steps required.

## Quick Start (Windows)
1. Install Python 3.10+ and run:
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Put your input file at `data/input.csv` (see sample below).
3. Place your masters:
   - `data/master_data.csv`  (authoritative city+state+pincode combos)
   - `data/pincode_master.csv` (authoritative pincode -> city,state mapping)
4. Run:
   ```bat
   py -m app.cli ^
     --input data\input.csv ^
     --out data\validated_output.parquet ^
     --csv-out data\validated_output.csv
   ```
5. Open the CSV/Parquet in Excel/Power BI/etc.

### Input schema (CSV)
Columns (case-insensitive accepted):
- `address1`, `address2` (optional), `address3` (optional), `city` (optional), `state` (optional), `pincode` (optional), `record_id` (optional but recommended)

### Output columns
- `record_id`
- `input_address1`, `input_address2`, `input_address3`, `input_city`, `input_state`, `input_pincode`
- `norm_city`, `norm_state`, `norm_pincode`
- `corrected_city`, `corrected_state`
- `match_source` in {NONE, MASTER_DATA, PINCODE_MASTER, BOTH}
- `is_flagged` (True/False)
- `flag_reasons` (pipe `|` delimited)
- `confidence` (0..1)

## Master CSV formats
`master_data.csv` (at minimum):
```
pincode,city,state
110001,NEW DELHI,DELHI
560001,BENGALURU,KARNATAKA
```
`pincode_master.csv`:
```
pincode,city,state
110001,NEW DELHI,DELHI
560001,BENGALURU,KARNATAKA
```
> You can have extra columns; only the above are required.

## Examples
Sample files are provided under `data/`:
- `input.csv` – 6 sample rows
- `master_data.csv` – tiny demo
- `pincode_master.csv` – tiny demo

## Notes
- If both masters disagree, precedence is `pincode_master` (as pincode→(city,state) mapping is typically canonical). We still set `match_source=BOTH`.
- We **never** mark as flagged when matched in **either** master.
- Confidence rubric (simplified):
  - `BOTH`: 1.00
  - `PINCODE_MASTER`: 0.98
  - `MASTER_DATA`: 0.95
  - `NONE`:
    - city+state present but pincode missing/invalid: 0.50
    - minimal info: 0.30

## Troubleshooting
- Ensure your CSVs are UTF‑8 encoded.
- Remove stray BOMs if Excel created them.
- Use only digits in `pincode` (6 digits). Non‑digit characters are ignored during normalization.
