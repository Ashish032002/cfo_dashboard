from typing import Tuple, Optional

def resolve_by_pincode(pincode: str, pincode_map: dict) -> Tuple[Optional[str], Optional[str]]:
    # Return (city, state) for pincode if present in pincode_map.
    rec = pincode_map.get(pincode)
    if rec:
        return rec["city"], rec["state"]
    return None, None

def in_master(city: str, state: str, pincode: str, master_set: set) -> bool:
    # Check if tuple exists in master_data set.
    return (city, state, pincode) in master_set
