from typing import List

def invalid_pincode_reason(pincode: str) -> List[str]:
    reasons = []
    if not pincode:
        reasons.append("INVALID_PINCODE_FORMAT")
    elif not pincode.isdigit() or len(pincode) != 6:
        reasons.append("INVALID_PINCODE_FORMAT")
    return reasons
