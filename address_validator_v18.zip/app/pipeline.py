from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple
import pandas as pd

from .normalization import norm_city, norm_state, norm_pincode, has_valid_pincode, detect_multi_entities, norm_text
from .matcher import resolve_by_pincode, in_master

@dataclass
class ResultRow:
    record_id: str
    input_address1: str
    input_address2: str
    input_address3: str
    input_city: str
    input_state: str
    input_pincode: str

    norm_city: str
    norm_state: str
    norm_pincode: str

    corrected_city: str
    corrected_state: str
    match_source: str  # NONE | MASTER_DATA | PINCODE_MASTER | BOTH
    is_flagged: bool
    flag_reasons: str
    confidence: float

def load_master_frames(master_data_path, pincode_master_path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    md = pd.read_csv(master_data_path, dtype=str).fillna("")
    pm = pd.read_csv(pincode_master_path, dtype=str).fillna("")
    # normalize key fields
    md["city_n"] = md["city"].map(norm_city)
    md["state_n"] = md["state"].map(norm_state)
    md["pincode_n"] = md["pincode"].map(norm_pincode)
    pm["city_n"] = pm["city"].map(norm_city)
    pm["state_n"] = pm["state"].map(norm_state)
    pm["pincode_n"] = pm["pincode"].map(norm_pincode)
    return md, pm

def build_master_indexes(md: pd.DataFrame, pm: pd.DataFrame):
    master_set = set(zip(md["city_n"], md["state_n"], md["pincode_n"]))
    pincode_map: Dict[str, Dict[str, str]] = {}
    for _, r in pm.iterrows():
        pin = r["pincode_n"]
        if pin and pin not in pincode_map:  # first wins
            pincode_map[pin] = {"city": r["city_n"], "state": r["state_n"]}
    known_states = set(md["state_n"]).union(set(pm["state_n"]))
    known_cities = set(md["city_n"]).union(set(pm["city_n"]))
    return master_set, pincode_map, known_states, known_cities

def confidence_from_match(match_source: str, has_city_state: bool) -> float:
    if match_source == "BOTH":
        return 1.00
    if match_source == "PINCODE_MASTER":
        return 0.98
    if match_source == "MASTER_DATA":
        return 0.95
    # NONE
    return 0.50 if has_city_state else 0.30

def process(df: pd.DataFrame, md_path, pm_path) -> pd.DataFrame:
    md, pm = load_master_frames(md_path, pm_path)
    master_set, pincode_map, known_states, known_cities = build_master_indexes(md, pm)

    # Standardize expected columns
    cols = {c.lower(): c for c in df.columns}
    def get(col): 
        for k in cols:
            if k == col:
                return cols[k]
        return None

    addr1 = get("address1") or "address1"
    addr2 = get("address2") or "address2"
    addr3 = get("address3") or "address3"
    city_c = get("city") or "city"
    state_c = get("state") or "state"
    pin_c = get("pincode") or "pincode"
    recid_c = get("record_id") or "record_id"

    if recid_c not in df.columns:
        df[recid_c] = df.index.astype(str)

    # Ensure all columns exist
    for c in [addr1, addr2, addr3, city_c, state_c, pin_c]:
        if c not in df.columns:
            df[c] = ""

    out: List[ResultRow] = []
    for _, r in df.iterrows():
        in_a1 = str(r[addr1]) if addr1 in r else ""
        in_a2 = str(r[addr2]) if addr2 in r else ""
        in_a3 = str(r[addr3]) if addr3 in r else ""
        in_city = str(r[city_c]) if city_c in r else ""
        in_state = str(r[state_c]) if state_c in r else ""
        in_pin = str(r[pin_c]) if pin_c in r else ""
        rec_id = str(r[recid_c])

        n_city = norm_city(in_city)
        n_state = norm_state(in_state)
        n_pin = norm_pincode(in_pin)

        # Conservative multi-entity checks (on concatenated address text)
        full_text = " ".join([in_a1, in_a2, in_a3, in_city, in_state])
        multi_state, multi_city = detect_multi_entities(full_text, known_states, known_cities)

        reasons = []
        if multi_state: reasons.append("MULTI_STATE_IN_ADDRESS")
        if multi_city: reasons.append("MULTI_CITY_IN_ADDRESS")
        if n_pin and (not n_pin.isdigit() or len(n_pin) != 6):
            reasons.append("INVALID_PINCODE_FORMAT")

        # Prefer pincode→(city,state) when available
        pc_city, pc_state = (None, None)
        if n_pin and n_pin.isdigit() and len(n_pin) == 6:
            pc_city, pc_state = resolve_by_pincode(n_pin, pincode_map)

        corrected_city = n_city
        corrected_state = n_state
        match_source = "NONE"

        if pc_city and pc_state:
            corrected_city, corrected_state = pc_city, pc_state
            # Also check master_set consistency
            in_master_b = in_master(corrected_city, corrected_state, n_pin, master_set)
            match_source = "BOTH" if in_master_b else "PINCODE_MASTER"
        else:
            # Fall back to master_data exact tuple check if we have all 3
            if n_city and n_state and n_pin and (n_pin.isdigit() and len(n_pin) == 6):
                if in_master(n_city, n_state, n_pin, master_set):
                    corrected_city, corrected_state = n_city, n_state
                    match_source = "MASTER_DATA"

        # If still NONE, assess partials
        if match_source == "NONE":
            if n_city and n_state and not n_pin:
                reasons.append("PINCODE_NOT_FOUND")
            else:
                reasons.append("NOT_IN_MASTER")

        # DO NOT flag if matched in either dataset
        is_flagged = False if match_source in ("PINCODE_MASTER", "MASTER_DATA", "BOTH") else True

        # Conflict check only if matched by pincode but user's city/state differ
        if match_source in ("PINCODE_MASTER", "BOTH"):
            if (n_city and n_city != corrected_city) or (n_state and n_state != corrected_state):
                # Not flagged because pincode is authoritative, but record the info
                reasons.append("CONFLICT_CITY_STATE")

        conf = confidence_from_match(match_source, bool(n_city and n_state))

        out.append(ResultRow(
            record_id=rec_id,
            input_address1=in_a1, input_address2=in_a2, input_address3=in_a3,
            input_city=in_city, input_state=in_state, input_pincode=in_pin,
            norm_city=n_city, norm_state=n_state, norm_pincode=n_pin,
            corrected_city=corrected_city, corrected_state=corrected_state,
            match_source=match_source, is_flagged=is_flagged,
            flag_reasons="|".join(sorted(set(reasons))) if reasons else "",
            confidence=round(conf, 3)
        ))

    out_df = pd.DataFrame([asdict(x) for x in out])
    return out_df
