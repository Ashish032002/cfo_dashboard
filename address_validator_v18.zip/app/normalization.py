import re

PUNCT_RE = re.compile(r"[^\w\s]")
SPACE_RE = re.compile(r"\s+")
NON_DIGIT_RE = re.compile(r"\D+")

ALIASES_CITY = {
    "BANGALORE": "BENGALURU",
    "BENGALORE": "BENGALURU",
    "BOMBAY": "MUMBAI",
    "DELHI NCR": "DELHI",
}
ALIASES_STATE = {
    "UTTARANCHAL": "UTTARAKHAND",
    "ORISSA": "ODISHA",
    "JAMMU & KASHMIR": "JAMMU AND KASHMIR",
    "PONDICHERRY": "PUDUCHERRY",
    "NCT OF DELHI": "DELHI",
}

def norm_text(x: str) -> str:
    if x is None:
        return ""
    x = str(x).strip().upper()
    x = PUNCT_RE.sub(" ", x)
    x = SPACE_RE.sub(" ", x).strip()
    return x

def norm_city(x: str) -> str:
    y = norm_text(x)
    return ALIASES_CITY.get(y, y)

def norm_state(x: str) -> str:
    y = norm_text(x)
    return ALIASES_STATE.get(y, y)

def norm_pincode(x: str) -> str:
    if x is None:
        return ""
    digits = NON_DIGIT_RE.sub("", str(x))
    if len(digits) == 6:
        return digits
    # keep only up to 6 digits; invalid handled later
    return digits[:6]

def has_valid_pincode(x: str) -> bool:
    return x.isdigit() and len(x) == 6

def detect_multi_entities(text: str, known_states: set, known_cities: set):
    # Very conservative detection for multi-city/state mentions in free-form addresses.
    # We do NOT explode combinations; only flag if we clearly see >1 distinct known entity.
    if not text:
        return False, False
    t = norm_text(text)
    s_hits = {s for s in known_states if s and f" {s} " in f" {t} "}
    c_hits = {c for c in known_cities if c and f" {c} " in f" {t} "}
    return (len(s_hits) > 1), (len(c_hits) > 1)
