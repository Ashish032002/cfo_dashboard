import argparse
import pandas as pd
from . import config
from .pipeline import process

def main():
    ap = argparse.ArgumentParser(description=f"Address Validator {config.VERSION}")
    ap.add_argument("--input", type=str, default=str(config.DEFAULT_INPUT), help="Path to input CSV")
    ap.add_argument("--master", type=str, default=str(config.MASTER_DATA), help="Path to master_data.csv")
    ap.add_argument("--pincode-master", type=str, default=str(config.PINCODE_MASTER), help="Path to pincode_master.csv")
    ap.add_argument("--out", type=str, default=str(config.DEFAULT_OUT_PARQUET), help="Output Parquet path")
    ap.add_argument("--csv-out", type=str, default=str(config.DEFAULT_OUT_CSV), help="Optional CSV output path")
    args = ap.parse_args()

    df = pd.read_csv(args.input, dtype=str).fillna("")
    out = process(df, args.master, args.pincode_master)
    out.to_parquet(args.out, index=False)
    if args.csv_out:
        out.to_csv(args.csv_out, index=False)

    print(f"Saved: {args.out}")
    if args.csv_out:
        print(f"Saved CSV: {args.csv_out}")

if __name__ == "__main__":
    main()
