from pathlib import Path

VERSION = "v18"

# Default locations (override via CLI)
DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DEFAULT_INPUT = DATA_DIR / "input.csv"
MASTER_DATA = DATA_DIR / "master_data.csv"
PINCODE_MASTER = DATA_DIR / "pincode_master.csv"
DEFAULT_OUT_PARQUET = DATA_DIR / "validated_output.parquet"
DEFAULT_OUT_CSV = DATA_DIR / "validated_output.csv"
LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
