import os
from sqlalchemy import create_engine

def get_db_connection():
    host=os.getenv('AV_DB_HOST','localhost')
    port=int(os.getenv('AV_DB_PORT','5432'))
    name=os.getenv('AV_DB_NAME','addressdb')
    user=os.getenv('AV_DB_USER','postgres')
    pwd =os.getenv('AV_DB_PASS','postgres')
    url=f'postgresql+psycopg2://{user}:{pwd}@{host}:{port}/{name}'
    return create_engine(url, pool_pre_ping=True, future=True)
