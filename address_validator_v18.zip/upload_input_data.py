import os, pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

def main():
    here=os.path.dirname(__file__)
    for path in [os.path.join(here,'Input_address_2.xlsx'),'/mnt/data/Input_address_2.xlsx']:
        if os.path.exists(path):
            df=pd.read_excel(path); break
    else:
        raise FileNotFoundError('Input_address_2.xlsx not found.')
    df.columns=df.columns.str.strip().str.lower()
    for c in ['address1','address2','address3','city','state','pincode']:
        if c not in df.columns: df[c]=''
    df=df[['address1','address2','address3','city','state','pincode']].fillna('')
    eng=get_db_connection()
    with eng.begin() as con:
        con.execute(text('TRUNCATE av.input_addresses RESTART IDENTITY CASCADE'))
        for _,r in df.iterrows():
            con.execute(text("""INSERT INTO av.input_addresses(address1,address2,address3,city,state,pincode)
                              VALUES(:a1,:a2,:a3,:c,:s,:p)"""),
                        {'a1':r['address1'],'a2':r['address2'],'a3':r['address3'],'c':r['city'],'s':r['state'],'p':str(r['pincode'])})
    print(f'Loaded {len(df)} rows into av.input_addresses')

if __name__=='__main__': main()
