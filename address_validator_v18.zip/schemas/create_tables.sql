-- Optional reference if using a DB later. Not required for CSV mode.
CREATE TABLE IF NOT EXISTS master_ref (
  pincode CHAR(6) NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS pincode_master_ref (
  pincode CHAR(6) PRIMARY KEY,
  city TEXT NOT NULL,
  state TEXT NOT NULL
);
