
# Address Validator v14 (Merged master_data.csv + pincode_master.xlsx)

## What's new
- Merges **master_data.csv** (DivisionName/StateName/Pincode) + **pincode_master.xlsx** into **av.master_ref**
- Removes all office_name logic
- Cleans DivisionName → pure city (drops words like "Division", "Division Office")
- State abbreviations normalized to full names
- Batch processing (10k), Excel + DB per batch
- possible_addresses includes **both input and master** city/state

## Run order
1) `python create_schema.py`
2) Place `master_data.csv` and/or `pincode_master.xlsx` next to the scripts
3) `python upload_master_data.py`
4) Place `Input_address_2.xlsx` (or input.xlsx/csv) next to the scripts
5) `python upload_input_data.py`
6) `python validator_final_v14.py`

Tables:
- `av.master_ref(city,state,pincode)`
- `av.input_addresses(id,address1,address2,address3,city,state,pincode)`
- `av.validation_result_final(...)`
