
import os, pandas as pd, re
from sqlalchemy import text
from db_config import get_db_connection

def norm_pin(s):
    if pd.isna(s): return None
    m = re.search(r'(\d{6})', str(s))
    return m.group(1) if m else None

def clean_division_to_city(x: str) -> str:
    s = str(x or "").strip().title()
    s = re.sub(r'\bDivision(?: Office)?\b', '', s, flags=re.IGNORECASE).strip()
    s = re.sub(r'\s+', ' ', s)
    return s

def load_master_csv(csv_path):
    df = pd.read_csv(csv_path)
    cols = {c.lower().strip(): c for c in df.columns}
    div = cols.get("divisionname") or cols.get("division")
    st  = cols.get("statename") or cols.get("state")
    pin = cols.get("pincode") or cols.get("pin code") or cols.get("pin")
    if not (div and st and pin):
        raise ValueError(f"master_data.csv must include DivisionName/StateName/Pincode. Found: {list(df.columns)}")
    out = pd.DataFrame({
        "city": df[div].apply(clean_division_to_city),
        "state": df[st].astype(str).str.strip().str.title(),
        "pincode": df[pin].apply(norm_pin)
    })
    return out.dropna(subset=["pincode"])

def load_master_xlsx(xlsx_path):
    df = pd.read_excel(xlsx_path)
    cols = {c.lower().strip(): c for c in df.columns}
    div = cols.get("divisionname") or cols.get("division") or cols.get("city")
    st  = cols.get("statename") or cols.get("state")
    pin = cols.get("pincode") or cols.get("pin code") or cols.get("pin")
    if not (div and st and pin):
        raise ValueError(f"pincode_master.xlsx missing core columns. Found: {list(df.columns)}")
    out = pd.DataFrame({
        "city": df[div].apply(clean_division_to_city),
        "state": df[st].astype(str).str.strip().str.title(),
        "pincode": df[pin].apply(norm_pin)
    })
    return out.dropna(subset=["pincode"])

def main():
    here = os.path.dirname(__file__)
    csv_path  = os.path.join(here, "master_data.csv")
    xlsx_path = os.path.join(here, "pincode_master.xlsx")

    frames = []
    if os.path.exists(csv_path):
        frames.append(load_master_csv(csv_path).assign(_src="csv"))
    if os.path.exists(xlsx_path):
        frames.append(load_master_xlsx(xlsx_path).assign(_src="xlsx"))
    if not frames:
        raise FileNotFoundError("Place at least one of: master_data.csv, pincode_master.xlsx next to this script.")

    merged = pd.concat(frames, ignore_index=True)
    # csv rows first ensure priority over xlsx on duplicates
    merged["pincode"] = merged["pincode"].astype(str).str.extract(r'(\d{6})', expand=False)
    merged["city"]    = merged["city"].astype(str).str.strip().str.title()
    merged["state"]   = merged["state"].astype(str).str.strip().str.title()
    merged = merged.dropna(subset=["pincode"])
    merged = merged.drop_duplicates(subset=["pincode","city","state"], keep="first")

    eng = get_db_connection()
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.master_ref RESTART IDENTITY CASCADE"))
        merged[["city","state","pincode"]].to_sql("master_ref", con, schema="av", if_exists="append", index=False)
    print(f"Merged master loaded: {len(merged):,} rows (csv prioritized over xlsx).")

if __name__ == "__main__":
    main()
