import re
PIN_RE=re.compile(r'(?<!\d)(\d{6})(?!\d)')

def extract_pin(t):
    m=PIN_RE.search(str(t)); return m.group(1) if m else None

def clean_text(s):
    return str(s or '').strip().lower()

def token_set_sim(a,b):
    return 1.0 if (a or '').strip().lower()==(b or '').strip().lower() else 0.0
