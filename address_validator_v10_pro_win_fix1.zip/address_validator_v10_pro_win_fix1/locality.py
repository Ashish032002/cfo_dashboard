def extract_locality(a,*_):
    return None
