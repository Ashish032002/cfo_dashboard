import pandas as pd
from dataclasses import dataclass
from typing import Dict, List
from .text_utils import clean_text, token_set_sim, extract_pin
from .state_maps import load_state_mappings, normalize_state
from .constants import CITY_ALIASES, W_CITY, W_STATE, W_PIN, HIGH_CONF, MED_CONF

def normalize_city(s):
    return clean_text(s).title()

def conf_level(x):
    return 'High' if x>=HIGH_CONF else ('Medium' if x>=MED_CONF else 'Low')

@dataclass
class Decision:
    status:str; reason:str; confidence:float; confidence_level:str
    city_confidence:float; state_confidence:float; chosen:Dict; suggestions:List[Dict]

class AddressValidator:
    def __init__(self, master_df, *_):
        self.master=master_df.copy()
        self.master['pincode']=self.master['pincode'].astype(str)
        self.master['city_norm']=self.master['city'].apply(normalize_city)
        self.master['state_norm']=self.master['state'].apply(lambda s: normalize_state(s,{},{}))
        self.by_pin={k:v for k,v in self.master.groupby('pincode')}
    def score(self,cs,ss,pm):
        return W_CITY*cs+W_STATE*ss+W_PIN*(1.0 if pm else 0.0)
    def decide(self, r:Dict)->Decision:
        addr=' '.join([str(r.get('address1') or ''),str(r.get('address2') or ''),str(r.get('address3') or '')])
        pin=extract_pin(addr) or extract_pin(r.get('pincode'))
        ic=normalize_city(r.get('city') or '')
        is_ = normalize_state(r.get('state') or '',{}, {})
        if pin and pin in self.by_pin:
            df=self.by_pin[pin]
            df['city_sim']=df['city_norm'].apply(lambda x: token_set_sim(x, ic))
            df['state_sim']=df['state_norm'].apply(lambda x: token_set_sim(x, is_))
            df['score']=df.apply(lambda x: self.score(x.city_sim,x.state_sim,True), axis=1)
            b=df.sort_values('score',ascending=False).iloc[0]
            return Decision('OK','Pincode found',float(b.score),conf_level(float(b.score)),float(b.city_sim),float(b.state_sim),
                {'pincode':pin,'city':b.city_norm,'state':b.state_norm,'country':'India'},
                df[['pincode','city_norm','state_norm']].drop_duplicates().to_dict('records'))
        else:
            return Decision('FLAG','Pincode missing/invalid',0.0,'Low',0.0,0.0,{'pincode':pin,'city':ic,'state':is_,'country':None},[])
