from sqlalchemy import create_engine
CONN_STR='postgresql+psycopg2://postgres:postgres@localhost:5432/postgres'

def get_db_connection():
    return create_engine(CONN_STR, pool_pre_ping=True)
