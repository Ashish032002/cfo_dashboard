def load_state_mappings(p=None):
    return {},{}

def normalize_state(s,a,b):
    return (s or '').title()
