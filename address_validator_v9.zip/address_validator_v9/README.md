
# Address Validator v9 (Enhanced)

✅ Fully implements flowchart logic  
✅ Adds **city_confidence**, **state_confidence**, **overall_confidence**  
✅ Adds input address columns at the front in Excel only  
✅ Database output remains clean and normalized  
✅ Primary keys ensured for both input (`input_id`) and output (`validation_id`)  

To run:
```bash
python -m address_validator_v9.main
```

Result:
- Writes DB table: `av.validation_result_final`
- Exports Excel: `/mnt/data/validation_results_v9.xlsx`
  (includes input columns + derived + confidences)
