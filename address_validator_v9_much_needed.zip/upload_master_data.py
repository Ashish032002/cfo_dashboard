
import os, pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

CANDIDATES = ["pincode_master.xlsx", "master_data.csv"]

def load_any():
    for fname in CANDIDATES:
        if os.path.exists(fname):
            if fname.endswith(".xlsx"):
                df = pd.read_excel(fname)
            else:
                df = pd.read_csv(fname)
            print(f"Loaded {len(df)} rows from {fname}")
            return df
    raise FileNotFoundError("Place pincode_master.xlsx or master_data.csv next to this script.")

def normalize(df):
    df = df.copy()
    df.columns = df.columns.str.strip().str.lower()
    rename_map = {}
    for c in df.columns:
        if c in ("divisionname","city_name","district","city"):
            rename_map[c] = "city"
        if c in ("statename","state_name","stname","state"):
            rename_map[c] = "state"
        if c in ("pincode","pin","zipcode","zip"):
            rename_map[c] = "pincode"
        if c in ("office_name","office","po_name","post_office","postoffice","po"):
            rename_map[c] = "office_name"
    df = df.rename(columns=rename_map)
    keep = ["city","state","pincode","office_name"]
    for k in keep:
        if k not in df.columns:
            df[k] = None
    for k in ["city","state","office_name"]:
        df[k] = df[k].astype(str).str.strip()
    df["pincode"] = df["pincode"].astype(str).str.extract(r"(\d{6})", expand=False)
    df = df.dropna(subset=["pincode"]).drop_duplicates(subset=["pincode","city","state","office_name"])
    return df[keep]

def main():
    eng = get_db_connection()
    df = normalize(load_any())
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.master_ref RESTART IDENTITY"))
        for _,r in df.iterrows():
            con.execute(text("""
                INSERT INTO av.master_ref(city,state,pincode,office_name)
                VALUES(:c,:s,:p,:o)
            """), {"c":r["city"],"s":r["state"],"p":r["pincode"],"o":r["office_name"]})
    print(f"Inserted {len(df)} rows into av.master_ref")

if __name__ == "__main__":
    main()
