
# Address Validator v9 (PostgreSQL, full flow)

## Run order
1) `python create_schema.py`
2) Add master file next to scripts: `pincode_master.xlsx` **or** `master_data.csv`
3) `python upload_master_data.py`
4) Add `Input_address_2.xlsx`
5) `python upload_input_data.py`
6) `python validator_final_v9.py`

- Batch = 10,000; each batch writes `validated_output_partN.xlsx` and inserts to DB.
- Locality extracted only from input address text.
- Output table: `av.validation_result_final` with PK `out_id` and `input_id` to link back.
