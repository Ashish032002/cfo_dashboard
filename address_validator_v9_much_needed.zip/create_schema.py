
from sqlalchemy import text
from db_config import get_db_connection

def main():
    eng = get_db_connection()
    with eng.begin() as con:
        con.execute(text("CREATE SCHEMA IF NOT EXISTS av"))
        con.execute(text("""
            CREATE TABLE IF NOT EXISTS av.input_addresses (
                id BIGSERIAL PRIMARY KEY,
                address1 TEXT, address2 TEXT, address3 TEXT,
                city TEXT, state TEXT, pincode TEXT
            )
        """))
        con.execute(text("""
            CREATE TABLE IF NOT EXISTS av.master_ref (
                id BIGSERIAL PRIMARY KEY,
                city TEXT,
                state TEXT,
                pincode TEXT,
                office_name TEXT
            )
        """))
        con.execute(text("""
            CREATE TABLE IF NOT EXISTS av.validation_result_final (
                out_id BIGINT PRIMARY KEY,
                input_id BIGINT,
                address1 TEXT, city TEXT, state TEXT, pincode TEXT, country TEXT,
                city_confidence NUMERIC, state_confidence NUMERIC,
                overall_confidence NUMERIC, confidence_level TEXT,
                flag TEXT, reason TEXT, locality TEXT
            )
        """))
    print("Schema and tables created/verified.")

if __name__ == "__main__":
    main()
