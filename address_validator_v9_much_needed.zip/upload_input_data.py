
import pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

INPUT_XLSX = "Input_address_2.xlsx"

def main():
    eng = get_db_connection()
    df = pd.read_excel(INPUT_XLSX)
    df.columns = df.columns.str.strip().str.lower()
    expected = ["address1","address2","address3","city","state","pincode"]
    missing = [c for c in expected if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns in input Excel: {missing}")
    for c in expected:
        if c != "pincode":
            df[c] = df[c].astype(str).str.strip()
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.input_addresses RESTART IDENTITY"))
        for _, r in df.iterrows():
            con.execute(text("""
                INSERT INTO av.input_addresses(address1,address2,address3,city,state,pincode)
                VALUES(:a1,:a2,:a3,:c,:s,:p)
            """), {
                "a1": None if pd.isna(r["address1"]) else str(r["address1"]),
                "a2": None if pd.isna(r["address2"]) else str(r["address2"]),
                "a3": None if pd.isna(r["address3"]) else str(r["address3"]),
                "c": None if pd.isna(r["city"]) else str(r["city"]),
                "s": None if pd.isna(r["state"]) else str(r["state"]),
                "p": None if pd.isna(r["pincode"]) else str(r["pincode"]),
            })
    print("Loaded input rows into av.input_addresses")

if __name__ == "__main__":
    main()
