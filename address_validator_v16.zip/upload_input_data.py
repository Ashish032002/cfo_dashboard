
import os, pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

def main():
    eng = get_db_connection()
    path = None
    for c in [os.path.join(os.path.dirname(__file__),"Input_address_2.xlsx"),
              "/mnt/data/Input_address_2.xlsx"]:
        if os.path.exists(c):
            path = c; break
    if not path:
        raise FileNotFoundError("Input_address_2.xlsx not found.")
    df = pd.read_excel(path)
    df.columns = [c.strip().lower() for c in df.columns]
    for col in ["address1","address2","address3","city","state","pincode"]:
        if col not in df.columns: df[col] = ""
    df = df[["address1","address2","address3","city","state","pincode"]].fillna("")
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.input_addresses RESTART IDENTITY CASCADE"))
        for _, r in df.iterrows():
            con.execute(text("""INSERT INTO av.input_addresses(address1,address2,address3,city,state,pincode)
                                VALUES(:a1,:a2,:a3,:c,:s,:p)"""),
                        {"a1":r["address1"],"a2":r["address2"],"a3":r["address3"],
                         "c":r["city"],"s":r["state"],"p":str(r["pincode"]) })
    print(f"Loaded {len(df)} input rows into av.input_addresses")

if __name__ == "__main__":
    main()
