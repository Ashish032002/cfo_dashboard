
import os, re, json, unicodedata, pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

try:
    from rapidfuzz import fuzz
    def sim(a,b): return fuzz.token_set_ratio(a or "", b or "")/100
except:
    import difflib
    def sim(a,b): return difflib.SequenceMatcher(None,(a or "").lower(),(b or "").lower()).ratio()

CITY_THR = 0.80
STATE_THR = 0.80
BATCH = 10000

STOP_WORDS = {"division","city","district","region","zone","south","north","east","west","office",
              "so","bo","po","post","branch","rms","ho","do","co","nodal","sub","urban","rural"}
ALIASES = {"bombay":"mumbai","calcutta":"kolkata","bengaluru":"bangalore","gurgaon":"gurugram",
           "gurugram":"gurgaon","trivandrum":"thiruvananthapuram","madras":"chennai",
           "nasik":"nashik","vadodara":"baroda","baroda":"vadodara"}

def strip_accents(s): 
    import unicodedata
    return ''.join(ch for ch in unicodedata.normalize('NFKD', str(s)) if not unicodedata.combining(ch))

def clean_text(s):
    s = strip_accents(str(s or "")).lower()
    s = re.sub(r"[^\w\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def normalize_city(s):
    s = clean_text(s)
    toks = [ALIASES.get(t, t) for t in s.split() if t not in STOP_WORDS]
    return " ".join(toks).strip().title()

def extract_pin(txt):
    if not txt: return None
    m = re.search(r"(?<!\d)(\d{6})(?!\d)", str(txt))
    return m.group(1) if m else None

def load_state_mappings():
    here = os.path.dirname(__file__)
    path = os.path.join(here, "datasets", "abbreviation_list 1.csv")
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip().str.title()
    df["State"] = df["State"].astype(str).str.strip().str.title()
    df["Abbreviation"] = df["Abbreviation"].astype(str).str.strip().str.upper()
    s2a = dict(zip(df["State"], df["Abbreviation"]))
    a2s = dict(zip(df["Abbreviation"], df["State"]))
    return s2a, a2s

def normalize_state(s, s2a, a2s):
    if s is None or str(s).strip()=="": return None
    t = clean_text(s).replace(".","").upper()
    if t in a2s: return a2s[t]
    return t.title()

def confidence(city_sim, state_sim):
    overall = 0.55*city_sim + 0.45*state_sim
    level = "High" if overall>=0.80 else ("Medium" if overall>=0.65 else "Low")
    return overall, level

def pick_locality(address_concat, input_city, master_city):
    txt = clean_text(address_concat).title()
    for w in set((input_city or "").split()+ (master_city or "").split()):
        txt = re.sub(rf"\b{re.escape(w)}\b", "", txt, flags=re.I)
    txt = re.sub(r"\s+", " ", txt).strip().title()
    return txt if txt else None

def validate_chunk(df_inp, by_pin, s2a, a2s):
    rows = []
    for _, r in df_inp.iterrows():
        input_id = int(r["id"])
        a1,a2,a3 = r.get("address1",""), r.get("address2",""), r.get("address3","")
        city_in, state_in, pin_in = r.get("city",""), r.get("state",""), str(r.get("pincode",""))
        full_addr = " ".join([str(x) for x in [a1,a2,a3,city_in,state_in,pin_in] if x and str(x).lower()!="nan"])

        pin = extract_pin(full_addr) or extract_pin(pin_in)
        city_n = normalize_city(city_in)
        state_n = normalize_state(state_in, s2a, a2s)

        flag="No"; reason=""; ambiguity="none"
        city_conf=state_conf=0.0
        best_city=city_n; best_state=state_n

        candidates = []
        if pin and pin in by_pin:
            dfp = by_pin[pin]
            for _,m in dfp.iterrows():
                mc = normalize_city(m["city"])
                ms = normalize_state(m["state"], s2a, a2s)
                cs = max(sim(mc, city_n), 0.0)
                # boost if master city appears within full address
                if sim(mc, clean_text(full_addr).title()) >= 0.80:
                    cs = max(cs, 0.90)
                ss = sim(ms, state_n) if state_n else 0.0
                candidates.append({"master_city":mc, "master_state":ms, "cs":cs, "ss":ss})
            candidates.sort(key=lambda x: (x["cs"], x["ss"]), reverse=True)
            if candidates:
                top = candidates[0]
                city_conf, state_conf = top["cs"], top["ss"]
                best_city, best_state = top["master_city"], top["master_state"]
                any_match = any( (c["cs"]>=CITY_THR and (not state_n or c["ss"]>=STATE_THR)) for c in candidates )
                if not any_match:
                    flag="Yes"; ambiguity="city/state mismatch"; reason="Nearest master differs"
        else:
            flag="Yes"; ambiguity="pincode not found"; reason="Pincode not in master_ref"

        overall, level = confidence(city_conf, state_conf)
        poss = []
        if flag=="Yes" and candidates:
            poss = candidates[:2]

        locality = pick_locality(" ".join([a1,a2,a3]).strip(), city_n, best_city)

        rows.append({
            "input_id": input_id,
            "address1": " ".join([str(x) for x in [a1,a2,a3] if x]).strip(),
            "city": best_city or city_n,
            "state": best_state or state_n,
            "pincode": pin,
            "country": "India",
            "city_confidence": round(city_conf,3),
            "state_confidence": round(state_conf,3),
            "overall_confidence": round(overall,3),
            "confidence_level": level,
            "flag": flag,
            "reason": reason,
            "ambiguity_type": ambiguity,
            "possible_addresses": poss,
            "in_address1": a1, "in_address2": a2, "in_address3": a3,
            "in_city": city_in, "in_state": state_in, "in_pincode": pin_in
        })
    return pd.DataFrame(rows)

def main():
    print("Starting Address Validator v16 ...")
    eng = get_db_connection()
    s2a, a2s = load_state_mappings()
    with eng.begin() as con:
        master = pd.read_sql("SELECT city,state,pincode FROM av.master_ref", con)
        inp = pd.read_sql("SELECT * FROM av.input_addresses ORDER BY id", con)
    by_pin = {k: v[["city","state","pincode"]].copy() for k,v in master.groupby("pincode")}
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.validation_result_final RESTART IDENTITY CASCADE"))
    total = len(inp); parts = (total + BATCH - 1)//BATCH
    for i in range(parts):
        start, end = i*BATCH, min((i+1)*BATCH, total)
        df_part = validate_chunk(inp.iloc[start:end].copy(), by_pin, s2a, a2s)
        out_cols = ["in_address1","in_address2","in_address3","in_city","in_state","in_pincode",
                    "input_id","address1","city","state","pincode","country",
                    "city_confidence","state_confidence","overall_confidence","confidence_level",
                    "flag","reason","ambiguity_type","possible_addresses"]
        df_part[out_cols].to_excel(f"/mnt/data/validated_output_part{i+1}.xlsx", index=False)
        with eng.begin() as con:
            for _, r in df_part.iterrows():
                con.execute(text("""
                    INSERT INTO av.validation_result_final
                    (input_id,address1,city,state,pincode,country,
                     city_confidence,state_confidence,overall_confidence,confidence_level,
                     flag,reason,ambiguity_type,possible_addresses,
                     in_address1,in_address2,in_address3,in_city,in_state,in_pincode)
                    VALUES
                    (:iid,:a,:c,:s,:p,:co,:cc,:sc,:oc,:cl,:f,:r,:amb,:pa::jsonb,:ia1,:ia2,:ia3,:ic,:is,:ip)
                """), {"iid": int(r["input_id"]), "a": r["address1"], "c": r["city"], "s": r["state"],
                       "p": r["pincode"], "co": r["country"], "cc": float(r["city_confidence"]),
                       "sc": float(r["state_confidence"]), "oc": float(r["overall_confidence"]),
                       "cl": r["confidence_level"], "f": r["flag"], "r": r["reason"],
                       "amb": r["ambiguity_type"], "pa": json.dumps(r["possible_addresses"]),
                       "ia1": r["in_address1"], "ia2": r["in_address2"], "ia3": r["in_address3"],
                       "ic": r["in_city"], "is": r["in_state"], "ip": r["in_pincode"]})
        print(f"Batch {i+1}/{parts} -> /mnt/data/validated_output_part{i+1}.xlsx ({len(df_part)} rows)")
    print("All done.")

if __name__ == "__main__":
    main()
