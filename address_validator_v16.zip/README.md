
# Address Validator v16 (Postgres, master_data.csv only)

## Steps
1. `python create_schema.py`
2. `python upload_master_data.py`  # reads master_data.csv
3. `python upload_input_data.py`   # reads Input_address_2.xlsx
4. `python validator_final_v16.py` # batches of 10k, Excel+DB

Excel includes original input columns first.
States abbreviations are normalized using datasets/abbreviation_list 1.csv.
