
import os, re, pandas as pd
from sqlalchemy import text
from db_config import get_db_connection

def normalize_division_to_city(x: str) -> str:
    s = str(x or "").strip()
    s = re.sub(r'\bdivision\b', '', s, flags=re.I).strip()
    return s.title()

def main():
    eng = get_db_connection()
    path = None
    for c in [os.path.join(os.path.dirname(__file__), "master_data.csv"),
              "/mnt/data/master_data.csv"]:
        if os.path.exists(c):
            path = c; break
    if not path:
        raise FileNotFoundError("master_data.csv not found.")
    df = pd.read_csv(path)
    cols = {c.lower().strip(): c for c in df.columns}
    def pick(cands):
        for k,v in cols.items():
            if k.replace(" ","") in [c.replace(" ","").lower() for c in cands]:
                return v
        return None
    div = pick(["divisionname","division","city","cityname"])
    st  = pick(["statename","state","state_name"])
    pin = pick(["pincode","pin","zip"])
    df = df[[div,st,pin]].rename(columns={div:"city", st:"state", pin:"pincode"})
    df["city"] = df["city"].apply(normalize_division_to_city)
    df["state"] = df["state"].astype(str).str.strip().str.title()
    df["pincode"] = df["pincode"].astype(str).str.extract(r'(\\d{6})', expand=False)
    df = df.dropna(subset=["pincode"]).drop_duplicates(subset=["pincode"])
    with eng.begin() as con:
        con.execute(text("TRUNCATE av.master_ref"))
        for _,r in df.iterrows():
            con.execute(text("INSERT INTO av.master_ref(city,state,pincode) VALUES(:c,:s,:p)"),
                        {"c":r["city"], "s":r["state"], "p":r["pincode"]})
    print(f"Loaded {len(df)} rows into av.master_ref")

if __name__ == "__main__":
    main()
