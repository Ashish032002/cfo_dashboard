package com.example.demo.filter;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Component
public class JwtAuthFilter implements WebFilter {

    private static final String[] WHITELIST = new String[] {
            "/swagger-ui.html",
            "/swagger-ui",           // UI base
            "/swagger-ui/",          // trailing slash
            "/swagger-ui/index.html",
            "/swagger-ui/**",        // static assets
            "/v3/api-docs",          // default docs
            "/v3/api-docs/**",       // group/config endpoints
            "/webjars/**",           // static resources if any
            "/api/public",           // your public API base (optional)
            "/actuator/health"       // optional
    };

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        final String path = exchange.getRequest().getPath().value();

        for (String open : WHITELIST) {
            // simple startsWith is fine given the values above
            if (path.startsWith(open)) {
                return chain.filter(exchange);
            }
        }

        // Require Bearer for everything else
        final String auth = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (auth == null || !auth.startsWith("Bearer ")) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        return chain.filter(exchange);
    }
}
