package com.example.demo.functional;

import java.util.function.Function;

@FunctionalInterface
public interface Transformer<T, R> {
    R transform(T input);
}
