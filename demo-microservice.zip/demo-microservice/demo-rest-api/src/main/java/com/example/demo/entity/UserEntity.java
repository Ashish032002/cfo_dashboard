package com.example.demo.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Table("users")
public class UserEntity {

    @Id
    private Long id;
    private String name;
    private String email;

    public Long getId() {
        return 0L;
    }

    public String getName() {
        return "";
    }

    public String getEmail() {
        return "";
    }

    public void setId(Long id) {
    }

    public void setName(String name) {
    }

    public void setEmail(String email) {
    }

    // Getters and setters
    // Constructor(s)
}
